package swing;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;

public class Proveedores1 extends JFrame {

	private JPanel contentPane;
	private JTextField txtCantidad;
	private JTextField txtCostoU;
	private JTextField txtEnvios;
	private JTextField txtCostoT;
	private JComboBox cboMarcas;
	private JComboBox cboProductos;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Proveedores1 frame = new Proveedores1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Proveedores1() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		setIconImage(Toolkit.getDefaultToolkit().getImage(Proveedores1.class.getResource("/iconos32/innovacion.png")));
		setBounds(100, 100, 445, 412);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setTitle("Proveedores");
		setBounds(100, 100, 445, 410);
		getContentPane().setLayout(null);
		contentPane.setLayout(null);
		setLocationRelativeTo(null);
		
		JLabel label = new JLabel("PRODUCTOS");
		label.setForeground(Color.BLUE);
		label.setBounds(10, 11, 89, 26);
		getContentPane().add(label);
		
		JLabel lblEmpresa = new JLabel("EMPRESA");
		lblEmpresa.setForeground(Color.BLUE);
		lblEmpresa.setBounds(10, 66, 89, 26);
		getContentPane().add(lblEmpresa);
		
		JLabel lblCantidad = new JLabel("CANTIDAD");
		lblCantidad.setForeground(Color.BLUE);
		lblCantidad.setBounds(10, 128, 89, 26);
		getContentPane().add(lblCantidad);
		
		cboProductos = new JComboBox();
		cboProductos.setModel(new DefaultComboBoxModel(new String[] {"Tostadoras", "Planchas", "Lavadoras", "Licuadoras", "Microondas", "Refrigeradoras", "Cocinas", "Ollas "}));
		cboProductos.setBounds(10, 31, 89, 37);
		getContentPane().add(cboProductos);
		
		cboMarcas = new JComboBox();
		cboMarcas.setModel(new DefaultComboBoxModel(new String[] {"LG", "Samsung", "Beko", "Electrolux", "Bosch", "Sony"}));
		cboMarcas.setBounds(10, 92, 89, 37);
		getContentPane().add(cboMarcas);
		
		
		
		JLabel lblNewLabel = new JLabel("");
		
		lblNewLabel.setBounds(109, 11, 310, 158);
		ImageIcon ico=new ImageIcon(getClass().getResource("marcas.png"));
		ImageIcon img=new ImageIcon(ico.getImage().getScaledInstance(lblNewLabel.getWidth(), lblNewLabel.getHeight(),Image.SCALE_SMOOTH));
		lblNewLabel.setIcon(img);
		getContentPane().add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBounds(103, 180, 316, 123);
		getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblCostoPorUnidad = new JLabel("Costo por unidad");
		lblCostoPorUnidad.setForeground(Color.BLUE);
		lblCostoPorUnidad.setBounds(0, 11, 111, 26);
		panel.add(lblCostoPorUnidad);
		
		JLabel lblGastosDeEnvio = new JLabel("Gastos de envio");
		lblGastosDeEnvio.setForeground(Color.BLUE);
		lblGastosDeEnvio.setBounds(121, 11, 94, 26);
		panel.add(lblGastosDeEnvio);
		
		JLabel lblCostoTotal = new JLabel("Costo total");
		lblCostoTotal.setForeground(Color.BLUE);
		lblCostoTotal.setBounds(225, 11, 81, 26);
		panel.add(lblCostoTotal);
		
		txtCostoU = new JTextField();
		txtCostoU.setColumns(10);
		txtCostoU.setBounds(10, 48, 89, 37);
		panel.add(txtCostoU);
		
		txtEnvios = new JTextField();
		txtEnvios.setColumns(10);
		txtEnvios.setBounds(118, 48, 89, 37);
		panel.add(txtEnvios);
		
		txtCostoT = new JTextField();
		txtCostoT.setColumns(10);
		txtCostoT.setBounds(217, 48, 89, 37);
		panel.add(txtCostoT);
		
		
		
		JButton button = new JButton("REGRESAR");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TiendaElectronica();
			}
		});
		button.setIcon(new ImageIcon(Proveedores1.class.getResource("/iconos32/carpeta.png")));
		button.setBounds(10, 319, 140, 41);
		getContentPane().add(button);
		
		JButton button_1 = new JButton("");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Limpiar();
			}
		});
		button_1.setIcon(new ImageIcon(Proveedores1.class.getResource("/iconos32/add-file.png")));
		button_1.setBounds(364, 319, 55, 41);
		getContentPane().add(button_1);
		
		JButton button_2 = new JButton("");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Procesar();
			}
		});
		button_2.setIcon(new ImageIcon(Proveedores1.class.getResource("/iconos32/proceso-automatizado.png")));
		button_2.setBounds(299, 319, 55, 41);
		getContentPane().add(button_2);
		
		txtCantidad = new JTextField();
		txtCantidad.setColumns(10);
		txtCantidad.setBounds(10, 157, 89, 37);
		contentPane.add(txtCantidad);

	}
	void TiendaElectronica(){
		this.setVisible(false);
		ProyectoTiendaElectronica PTE= new ProyectoTiendaElectronica();
		PTE.setVisible(true);
	}
	int cant,produc,marca;
	double precio,gastos,cosT;
	
	double[] PreProduc_Tostadoras;
	double[] Gastos_Tostadoras;
	
	double[] PreProduc_Planchas;
	double[] Gastos_Planchas;
	
	double[] PreProduc_Lavadoras;
	double[] Gastos_Lavadoras;
	
	double[] PreProduc_Licuadoras;
	double[] Gastos_Licuadoras;
	
	double[] PreProduc_Microondas;
	double[] Gastos_Microondas;
	
	double[] PreProduc_Refrigeradoras;
	double[] Gastos_Refrigeradoras;
	
	double[] PreProduc_Cocinas;
	double[] Gastos_Cocinas;
	
	double[] PreProduc_Ollas;
	double[] Gastos_Ollas;
	
	
	
	
	void leeDatos(){
       produc=cboProductos.getSelectedIndex();
       marca=cboMarcas.getSelectedIndex();
       cant=Integer.parseInt(txtCantidad.getText());
   	
       PreProduc_Tostadoras=new double[6];
  		PreProduc_Tostadoras[0]= 40.53;
  		PreProduc_Tostadoras[1]= 45.31;
  		PreProduc_Tostadoras[2]= 50.18;
  		PreProduc_Tostadoras[3]= 55.36;
  		PreProduc_Tostadoras[4]= 60.44;
  		PreProduc_Tostadoras[5]= 65.81;
  		
  		 PreProduc_Planchas=new double[6];
  		PreProduc_Planchas[0]= 45.55;
  		PreProduc_Planchas[1]= 50.32;
  		PreProduc_Planchas[2]= 55.18;
  		PreProduc_Planchas[3]= 60.35;
  		PreProduc_Planchas[4]= 65.48;
  		PreProduc_Planchas[5]= 70.89;
  		
  		 PreProduc_Lavadoras=new double[6];
  		PreProduc_Lavadoras[0]= 800.54;
  		PreProduc_Lavadoras[1]= 850.31;
  		PreProduc_Lavadoras[2]= 900.17;
  		PreProduc_Lavadoras[3]= 950.32;
  		PreProduc_Lavadoras[4]= 1000.47;
  		PreProduc_Lavadoras[5]= 1050.84;
  		
  		 PreProduc_Licuadoras=new double[6];
  		PreProduc_Licuadoras[0]= 120.55;
  		PreProduc_Licuadoras[1]= 130.37;
  		PreProduc_Licuadoras[2]= 140.11;
  		PreProduc_Licuadoras[3]= 150.32;
  		PreProduc_Licuadoras[4]= 160.49;
  		PreProduc_Licuadoras[5]= 170.83;
  		
  		 PreProduc_Microondas=new double[6];
  		PreProduc_Microondas[0]= 200.55;
  		PreProduc_Microondas[1]= 220.37;
  		PreProduc_Microondas[2]= 240.18;
  		PreProduc_Microondas[3]= 260.33;
  		PreProduc_Microondas[4]= 280.41;
  		PreProduc_Microondas[5]= 300.87;
  		
  		 PreProduc_Refrigeradoras=new double[6];
  		PreProduc_Refrigeradoras[0]= 1500.52;
  		PreProduc_Refrigeradoras[1]= 1900.33;
  		PreProduc_Refrigeradoras[2]= 2200.14;
  		PreProduc_Refrigeradoras[3]= 2500.31;
  		PreProduc_Refrigeradoras[4]= 2800.48;
  		PreProduc_Refrigeradoras[5]= 3100.82;
  		
  		 PreProduc_Cocinas=new double[6];
  		PreProduc_Cocinas[0]= 800.53;
  		PreProduc_Cocinas[1]= 1000.37;
  		PreProduc_Cocinas[2]= 1200.14;
  		PreProduc_Cocinas[3]= 1400.36;
  		PreProduc_Cocinas[4]= 1600.47;
  		PreProduc_Cocinas[5]= 1800.89;
  		
  		 PreProduc_Ollas=new double[6];
  		PreProduc_Ollas[0]= 70.51;
  		PreProduc_Ollas[1]= 80.32;
  		PreProduc_Ollas[2]= 95.14;
  		PreProduc_Ollas[3]= 100.35;
  		PreProduc_Ollas[4]= 110.48;
  		PreProduc_Ollas[5]= 115.83;

   		Gastos_Tostadoras=new double[6];
   		Gastos_Tostadoras[0]=11;
   		Gastos_Tostadoras[1]=12;
   		Gastos_Tostadoras[2]=13;
   		Gastos_Tostadoras[3]=14;
   		Gastos_Tostadoras[4]=15;
   		Gastos_Tostadoras[5]=16;
   		
   		Gastos_Planchas=new double[6];
   		Gastos_Planchas[0]=11;
   		Gastos_Planchas[1]=12;
   		Gastos_Planchas[2]=13;
   		Gastos_Planchas[3]=14;
   		Gastos_Planchas[4]=15;
   		Gastos_Planchas[5]=16;
   		
   		Gastos_Lavadoras=new double[6];
   		Gastos_Lavadoras[0]=21;
   		Gastos_Lavadoras[1]=22;
   		Gastos_Lavadoras[2]=23;
   		Gastos_Lavadoras[3]=24;
   		Gastos_Lavadoras[4]=25;
   		Gastos_Lavadoras[5]=26;
   		
   		Gastos_Licuadoras=new double[6];
   		Gastos_Licuadoras[0]=13;
   		Gastos_Licuadoras[1]=14;
   		Gastos_Licuadoras[2]=15;
   		Gastos_Licuadoras[3]=16;
   		Gastos_Licuadoras[4]=17;
   		Gastos_Licuadoras[5]=18;
   		
   		Gastos_Microondas=new double[6];
   		Gastos_Microondas[0]=13;
   		Gastos_Microondas[1]=14;
   		Gastos_Microondas[2]=15;
   		Gastos_Microondas[3]=16;
   		Gastos_Microondas[4]=17;
   		Gastos_Microondas[5]=18;
   		
   		Gastos_Refrigeradoras=new double[6];
   		Gastos_Refrigeradoras[0]=21;
   		Gastos_Refrigeradoras[1]=22;
   		Gastos_Refrigeradoras[2]=23;
   		Gastos_Refrigeradoras[3]=24;
   		Gastos_Refrigeradoras[4]=25;
   		Gastos_Refrigeradoras[5]=26;
   		
   		Gastos_Cocinas=new double[6];
   		Gastos_Cocinas[0]=21;
   		Gastos_Cocinas[1]=22;
   		Gastos_Cocinas[2]=23;
   		Gastos_Cocinas[3]=24;
   		Gastos_Cocinas[4]=25;
   		Gastos_Cocinas[5]=26;
   		
   		Gastos_Ollas=new double[6];
   		Gastos_Ollas[0]=11;
   		Gastos_Ollas[1]=12;
   		Gastos_Ollas[2]=13;
   		Gastos_Ollas[3]=14;
   		Gastos_Ollas[4]=15;
   		Gastos_Ollas[5]=16;
   		
   		

	}
	void Calculo(){

		
		switch(produc){
		case 0:
			Tostadoras();
          break;
 
		case 1:
			Planchas();
			break;
		case 2:
			Lavadoras();
			break;
		case 3: 
		Licuadoras();
		   break;
		case 4:
			Microondas();
			break;
		case 5: 
			 Refrigeradoras();	
			 break;
		case 6: 
			Cocinas();
			break;
		case 7: 
			Ollas();
			break;
		}
		
	}
    void Tostadoras(){
	
	switch(marca){
	case 0: 
	    precio=PreProduc_Tostadoras[0];
		gastos=Gastos_Tostadoras[0];
		
       break;
	case 1: 
		precio=PreProduc_Tostadoras[1];
		gastos=Gastos_Tostadoras[1];

	    break;
	case 2: 
		precio=PreProduc_Tostadoras[2];
		gastos=Gastos_Tostadoras[2];
	
	   break;
	case 3: 
		precio=PreProduc_Tostadoras[3];
		gastos=Gastos_Tostadoras[3];
		
	break;
	case 4:
		precio=PreProduc_Tostadoras[4]; 
		gastos=Gastos_Tostadoras[4];
		
		break;
	case 5: 
		precio=PreProduc_Tostadoras[5];
		gastos=Gastos_Tostadoras[5];
		
		break;
	}
	 
	 }
	void Planchas(){
		switch(marca){
		case 0: 
			precio=PreProduc_Planchas[0];
			gastos=Gastos_Planchas[0];
           break;
		case 1: 
			precio=PreProduc_Planchas[1];
			gastos=Gastos_Planchas[1];
		    break;
		case 2: 
			precio=PreProduc_Planchas[2];
			gastos=Gastos_Planchas[2];
		   break;
		case 3: 
			precio=PreProduc_Planchas[3];
			gastos=Gastos_Planchas[3];
		  break;
		case 4:
			precio=PreProduc_Planchas[4]; 
			gastos=Gastos_Planchas[4];
			break;
		case 5: 
			precio=PreProduc_Planchas[5];
			gastos=Gastos_Planchas[5];
			break;
		}
		
	}
	void Lavadoras(){
		
		switch(marca){
		case 0: 
			precio=PreProduc_Lavadoras[0];
			gastos=Gastos_Lavadoras[0];
           break;
		case 1: 
			precio=PreProduc_Lavadoras[1];
			gastos=Gastos_Lavadoras[1];
           break;
		case 2: 
			precio=PreProduc_Lavadoras[2];
			gastos=Gastos_Lavadoras[2];
           break;
		case 3: 
			precio=PreProduc_Lavadoras[3];
			gastos=Gastos_Lavadoras[3];
           break;
		case 4: 
			precio=PreProduc_Lavadoras[4];
			gastos=Gastos_Lavadoras[4];
           break;
		case 5: 
			precio=PreProduc_Lavadoras[5];
			gastos=Gastos_Lavadoras[5];
           break;
        
		}
		
	}
	void Licuadoras(){
		switch(marca){
		case 0: 
			precio=PreProduc_Licuadoras[0];
			gastos=Gastos_Licuadoras[0];
           break;
		case 1: 
			precio=PreProduc_Licuadoras[1];
			gastos=Gastos_Licuadoras[1];
           break;
		case 2: 
			precio=PreProduc_Licuadoras[2];
			gastos=Gastos_Licuadoras[2];
           break;
		case 3: 
			precio=PreProduc_Licuadoras[3];
			gastos=Gastos_Licuadoras[3];
           break;
		case 4: 
			precio=PreProduc_Licuadoras[4];
			gastos=Gastos_Licuadoras[4];
           break;
		case 5: 
			precio=PreProduc_Licuadoras[5];
			gastos=Gastos_Licuadoras[5];
           break;   
		}
		
	}
	void Microondas(){
		switch(marca){
		case 0: 
			precio=PreProduc_Microondas[0];
			gastos=Gastos_Microondas[0];
			
           break;
		case 1: 
			precio=PreProduc_Microondas[1];
			gastos=Gastos_Microondas[1];
           break;
		case 2: 
			precio=PreProduc_Microondas[2];
			gastos=Gastos_Microondas[2];
           break;
		case 3: 
			precio=PreProduc_Microondas[3];
			gastos=Gastos_Microondas[3];
           break;
		case 4: 
			precio=PreProduc_Microondas[4];
			gastos=Gastos_Microondas[4];
           break;
		case 5: 
			precio=PreProduc_Microondas[5];
			gastos=Gastos_Microondas[5];
           break;
		}
	}
	void Refrigeradoras(){
		 switch(marca){
			case 0: 
				precio=PreProduc_Refrigeradoras[0];
				gastos=Gastos_Refrigeradoras[0];
               break;
			case 1: 
				precio=PreProduc_Refrigeradoras[1];
				gastos=Gastos_Refrigeradoras[1];
               break;
			case 2: 
				precio=PreProduc_Refrigeradoras[2];
				gastos=Gastos_Refrigeradoras[2];
               break;
			case 3: 
				precio=PreProduc_Refrigeradoras[3];
				gastos=Gastos_Refrigeradoras[3];
               break;
			case 4: 
				precio=PreProduc_Refrigeradoras[4];
				gastos=Gastos_Refrigeradoras[4];
               break;
			case 5: 
				precio=PreProduc_Refrigeradoras[5];
				gastos=Gastos_Refrigeradoras[5];
               break;   

			}
			
	}
	void Cocinas(){
		switch(marca){
			case 0: 
				precio=PreProduc_Cocinas[0];
				gastos=Gastos_Cocinas[0];
              break;
			case 1: 
				precio=PreProduc_Cocinas[1];
				gastos=Gastos_Cocinas[1];
              break;
			case 2: 
				precio=PreProduc_Cocinas[2];
				gastos=Gastos_Cocinas[2];
              break;
			case 3: 
				precio=PreProduc_Cocinas[3];
				gastos=Gastos_Cocinas[3];
              break;
			case 4: 
				precio=PreProduc_Cocinas[4];
				gastos=Gastos_Cocinas[4];
              break;
			case 5: 
				precio=PreProduc_Cocinas[5];
				gastos=Gastos_Cocinas[5];
              break;   

		}			
		
		
	}
	void Ollas(){
		switch(marca){
			case 0: 
				precio=PreProduc_Ollas[0];
				gastos=Gastos_Ollas[0];
              break;
			case 1: 
				precio=PreProduc_Ollas[1];
				gastos=Gastos_Ollas[1];
              break;
			case 2: 
				precio=PreProduc_Ollas[2];
				gastos=Gastos_Ollas[2];
              break;
			case 3: 
				precio=PreProduc_Ollas[3];
				gastos=Gastos_Ollas[3];
              break;
			case 4: 
				precio=PreProduc_Ollas[4];
				gastos=Gastos_Ollas[4];
              break;
			case 5: 
				precio=PreProduc_Ollas[5];
				gastos=Gastos_Ollas[5];
              break;   

		}			
		
		
	}
	
	void CostoTotal(){
		gastos=Math.round(((gastos*=cant) * 100.0) / 100.0);
		cosT=Math.round(((precio*cant)+gastos) * 100.0) / 100.0;
	}
	void imprimir(){
		txtCostoU.setText(""+ precio);
		txtEnvios.setText(""+ gastos);
		txtCostoT.setText(""+ cosT);
	}
	void Procesar(){
		leeDatos();
		Calculo();
		CostoTotal();
		imprimir();
		
	}
	void Limpiar(){
		cboProductos.setSelectedIndex(-1);
		cboMarcas.setSelectedIndex(-1);
		txtCantidad.setText(null);
		txtCostoU.setText(null);
		txtEnvios.setText(null);
        txtCostoT.setText(null);
        cboProductos.requestFocus();
	}

}

package swing;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.Toolkit;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Login extends JFrame {

	private JPanel contentPane;
	private JTextField txtUsuario;
	private JPasswordField passContrase�a;
	private JLabel lblUsuario;
	private JLabel lblContrasea;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		setTitle("LOGIN");
		setIconImage(Toolkit.getDefaultToolkit().getImage(Login.class.getResource("/iconos32/ubuntu.png")));
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 445, 410);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(211, 211, 211));
		contentPane.setForeground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setLocationRelativeTo(null);
		
		JLabel lblNewLabel = new JLabel("INGRESAR AL GESTOR");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel.setForeground(Color.BLACK);
		lblNewLabel.setBounds(139, 131, 178, 55);
		contentPane.add(lblNewLabel);
		
		txtUsuario = new JTextField();
		txtUsuario.setBounds(178, 197, 194, 33);
		contentPane.add(txtUsuario);
		txtUsuario.setColumns(10);
		
		passContrase�a = new JPasswordField();
		passContrase�a.setBounds(178, 252, 194, 33);
		contentPane.add(passContrase�a);
		
		lblUsuario = new JLabel("USUARIO");
		lblUsuario.setIcon(new ImageIcon(Login.class.getResource("/iconos32/silueta-de-multiples-usuarios.png")));
		lblUsuario.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblUsuario.setForeground(Color.BLUE);
		lblUsuario.setBounds(51, 197, 117, 33);
		contentPane.add(lblUsuario);
		
		lblContrasea = new JLabel("CONTRASE\u00D1A");
		lblContrasea.setIcon(new ImageIcon(Login.class.getResource("/iconos32/bloquear.png")));
		lblContrasea.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblContrasea.setForeground(Color.BLUE);
		lblContrasea.setBounds(38, 246, 130, 42);
		contentPane.add(lblContrasea);
		
		JButton btnNewButton = new JButton("Ingresar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				
				Procesar();
			}

			private void setVisible(boolean b) {
				// TODO Auto-generated method stub
				
			}
		});
		btnNewButton.setIcon(new ImageIcon(Login.class.getResource("/iconos32/ingresos.png")));
		btnNewButton.setBounds(234, 319, 184, 42);
		contentPane.add(btnNewButton);
		
		JButton btnSalir = new JButton("Salir");
		btnSalir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnSalir.setIcon(new ImageIcon(Login.class.getResource("/iconos32/flecha.png")));
		btnSalir.setBounds(21, 319, 184, 42);
		contentPane.add(btnSalir);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon("C:\\Users\\Alexander Vasquez\\Downloads\\empleado.png"));
		label.setBounds(44, 175, 32, 55);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("");
		label_1.setIcon(new ImageIcon("C:\\Users\\Alexander Vasquez\\Downloads\\bloquear.png"));
		label_1.setBounds(28, 247, 32, 32);
		contentPane.add(label_1);
		
		JLabel label_2 = new JLabel("");
		label_2.setIcon(new ImageIcon(Login.class.getResource("/iconos/equipo.png")));
		label_2.setBounds(156, 11, 134, 137);
		contentPane.add(label_2);
		
		JLabel label_3 = new JLabel("");
		label_3.setIcon(new ImageIcon("C:\\Users\\Alexander Vasquez\\Downloads\\embalaje.png"));
		label_3.setBounds(251, 11, 134, 137);
		contentPane.add(label_3);
		
		JLabel label_4 = new JLabel("");
		label_4.setBounds(21, 22, 161, 107);
		contentPane.add(label_4);
	}
	
	void Login(){
		char[] clave=passContrase�a.getPassword();
		String claveFinal=new String(clave);
		if(txtUsuario.getText().equals("Gestor_Principal") && claveFinal.equals("241202")){
			dispose();
			JOptionPane.showMessageDialog(null,"Bienvenido Al Gestor Principal","INGRESASTE",
			   JOptionPane.INFORMATION_MESSAGE);
			
			ProyectoTiendaElectronica PTE= new ProyectoTiendaElectronica();
			PTE.setVisible(true);
			
		}else{
			JOptionPane.showMessageDialog(null,"Usuario o contrase�a incorrecta","ERROR",
					JOptionPane.ERROR_MESSAGE);
			
			txtUsuario.setText("");
			passContrase�a.setText("");
			txtUsuario.requestFocus();
	}
	  }
	void Procesar(){
		Login();
	}
}

package swing;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;

public class Comprobantes1 extends JFrame {

	private JPanel contentPane;
	private JTextField txtCantidad;
	private JTextField txtPuntos;
	private JTextField txtFecha;
	private JComboBox cboProductos;
	private JComboBox cboMarcas;
	private JTextArea txtProceso;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Comprobantes1 frame = new Comprobantes1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Comprobantes1() {
		setResizable(false);
		setIconImage(Toolkit.getDefaultToolkit().getImage(Comprobantes1.class.getResource("/iconos32/innovacion.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setTitle("Comprobante de Pago");
		setIcon(true);
		setBounds(100, 100, 445, 410);
		getContentPane().setLayout(null);
		contentPane.setLayout(null);
		setLocationRelativeTo(null);
		
		JButton button = new JButton("REGRESAR");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TiendaElectronica();
			}
		});
		button.setIcon(new ImageIcon(Comprobantes1.class.getResource("/iconos32/carpeta.png")));
		button.setBounds(10, 319, 144, 41);
		getContentPane().add(button);
		
		JButton button_1 = new JButton("");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				limpiar();
			}
		});
		button_1.setIcon(new ImageIcon(Comprobantes1.class.getResource("/iconos32/add-file.png")));
		button_1.setBounds(364, 319, 55, 41);
		getContentPane().add(button_1);
		
		JButton button_2 = new JButton("");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Procesar();
			}
		});
		button_2.setIcon(new ImageIcon(Comprobantes1.class.getResource("/iconos32/proceso-automatizado.png")));
		button_2.setBounds(299, 319, 55, 41);
		getContentPane().add(button_2);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 165, 409, 147);
		getContentPane().add(scrollPane);
		
		txtProceso = new JTextArea();
		scrollPane.setViewportView(txtProceso);
		
		JLabel lblNewLabel = new JLabel("");
		
		lblNewLabel.setBounds(288, 11, 131, 143);
		ImageIcon ico=new ImageIcon(getClass().getResource("boleta.jpg"));
		ImageIcon img=new ImageIcon(ico.getImage().getScaledInstance(lblNewLabel.getWidth(), lblNewLabel.getHeight(),Image.SCALE_SMOOTH));
		lblNewLabel.setIcon(img);
		getContentPane().add(lblNewLabel);
		
		JLabel lblCanti = new JLabel("PRODUCTOS");
		lblCanti.setForeground(Color.BLUE);
		lblCanti.setBounds(10, 11, 77, 26);
		getContentPane().add(lblCanti);
		
		cboProductos = new JComboBox();
		cboProductos.setModel(new DefaultComboBoxModel(new String[] {"Tostadoras", "Planchas", "Lavadoras", "Licuadoras", "Microondas", "Refrigeradoras", "Cocinas", "Ollas "}));
		cboProductos.setBounds(87, 11, 97, 20);
		getContentPane().add(cboProductos);
		
		JLabel label = new JLabel("MARCA");
		label.setForeground(Color.BLUE);
		label.setBounds(10, 39, 67, 26);
		getContentPane().add(label);
		
		cboMarcas = new JComboBox();
		cboMarcas.setModel(new DefaultComboBoxModel(new String[] {"LG", "Samsung", "Beko", "Electrolux", "Bosch", "Sony"}));
		cboMarcas.setBounds(86, 39, 98, 20);
		getContentPane().add(cboMarcas);
		
		JLabel lblCantidad = new JLabel("CANTIDAD");
		lblCantidad.setForeground(Color.BLUE);
		lblCantidad.setBounds(10, 69, 67, 26);
		getContentPane().add(lblCantidad);
		
		
		
		JLabel lblPuntos = new JLabel("PUNTOS");
		lblPuntos.setForeground(Color.BLUE);
		lblPuntos.setBounds(10, 98, 67, 26);
		getContentPane().add(lblPuntos);
		
		
		
		JLabel lblFecha = new JLabel("FECHA");
		lblFecha.setForeground(Color.BLUE);
		lblFecha.setBounds(10, 128, 67, 26);
		getContentPane().add(lblFecha);
		
		txtCantidad = new JTextField();
		txtCantidad.setColumns(10);
		txtCantidad.setBounds(87, 72, 97, 20);
		contentPane.add(txtCantidad);
		
		txtPuntos = new JTextField();
		txtPuntos.setColumns(10);
		txtPuntos.setBounds(87, 101, 98, 20);
		contentPane.add(txtPuntos);
		
		txtFecha = new JTextField();
		txtFecha.setColumns(10);
		txtFecha.setBounds(87, 131, 97, 20);
		contentPane.add(txtFecha);
		
	
	}

	private void setIcon(boolean b) {
		// TODO Auto-generated method stub
		
	}
	void TiendaElectronica(){
		this.setVisible(false);
		ProyectoTiendaElectronica PTE= new ProyectoTiendaElectronica();
		PTE.setVisible(true);
	}
	
	
	int produc,marca,codigo,cantidad,puntos;
	double precio,sol,dolar,iTotal=0,iPagar; 
	String Improduc,ImMarca;
	String fecha;
	String Lineas="";
	
   /*LISTAS*/
	double[] PreProduc_Tostadoras;
	int [] CodProduc_Tostadoras;	
	String[] ImMarca_Tostadoras;
	
	double[] PreProduc_Planchas;
	int [] CodProduc_Planchas;	
	String[] ImMarca_Planchas;
	
	double[] PreProduc_Lavadoras;
	int [] CodProduc_Lavadoras;
	String[] ImMarca_Lavadoras;
	
	double[] PreProduc_Licuadoras;
	int [] CodProduc_Licuadoras;
	String[] ImMarca_Licuadoras;
	
	double[] PreProduc_Microondas;
	int [] CodProduc_Microondas;	
	String[] ImMarca_Microondas;
	
	double[] PreProduc_Refrigeradoras;
	int [] CodProduc_Refrigeradoras;	
	String[] ImMarca_Refrigeradoras;
	
	double[] PreProduc_Cocinas;
	int [] CodProduc_Cocinas;	
	String[] ImMarca_Cocinas;
	
	double[] PreProduc_Ollas;
	int [] CodProduc_Ollas;	
	String[] ImMarca_Ollas;
	
	
	
	
	void leeDatos(){
		//Datos de entrada
       produc=cboProductos.getSelectedIndex();
       marca=cboMarcas.getSelectedIndex();
       puntos=Integer.parseInt(txtPuntos.getText());
       cantidad=Integer.parseInt(txtCantidad.getText());
       fecha=txtFecha.getText();
       
   	//Precio del producto
   		 PreProduc_Tostadoras=new double[6];
   		PreProduc_Tostadoras[0]= 70.53;
   		PreProduc_Tostadoras[1]= 80.31;
   		PreProduc_Tostadoras[2]= 90.18;
   		PreProduc_Tostadoras[3]= 100.36;
   		PreProduc_Tostadoras[4]= 108.44;
   		PreProduc_Tostadoras[5]= 120.81;
   		
   		 PreProduc_Planchas=new double[6];
   		PreProduc_Planchas[0]= 70.55;
   		PreProduc_Planchas[1]= 80.32;
   		PreProduc_Planchas[2]= 90.18;
   		PreProduc_Planchas[3]= 100.35;
   		PreProduc_Planchas[4]= 108.48;
   		PreProduc_Planchas[5]= 120.89;
   		
   		 PreProduc_Lavadoras=new double[6];
   		PreProduc_Lavadoras[0]= 70.54;
   		PreProduc_Lavadoras[1]= 80.31;
   		PreProduc_Lavadoras[2]= 90.17;
   		PreProduc_Lavadoras[3]= 100.32;
   		PreProduc_Lavadoras[4]= 108.47;
   		PreProduc_Lavadoras[5]= 120.84;
   		
   		 PreProduc_Licuadoras=new double[6];
   		PreProduc_Licuadoras[0]= 70.55;
   		PreProduc_Licuadoras[1]= 80.37;
   		PreProduc_Licuadoras[2]= 90.11;
   		PreProduc_Licuadoras[3]= 100.32;
   		PreProduc_Licuadoras[4]= 108.49;
   		PreProduc_Licuadoras[5]= 120.83;
   		
   		 PreProduc_Microondas=new double[6];
   		PreProduc_Microondas[0]= 70.55;
   		PreProduc_Microondas[1]= 80.37;
   		PreProduc_Microondas[2]= 90.18;
   		PreProduc_Microondas[3]= 100.33;
   		PreProduc_Microondas[4]= 108.41;
   		PreProduc_Microondas[5]= 120.87;
   		
   		 PreProduc_Refrigeradoras=new double[6];
   		PreProduc_Refrigeradoras[0]= 70.52;
   		PreProduc_Refrigeradoras[1]= 80.33;
   		PreProduc_Refrigeradoras[2]= 90.14;
   		PreProduc_Refrigeradoras[3]= 100.31;
   		PreProduc_Refrigeradoras[4]= 108.48;
   		PreProduc_Refrigeradoras[5]= 120.82;
   		
   		 PreProduc_Cocinas=new double[6];
   		PreProduc_Cocinas[0]= 70.53;
   		PreProduc_Cocinas[1]= 80.37;
   		PreProduc_Cocinas[2]= 90.14;
   		PreProduc_Cocinas[3]= 100.36;
   		PreProduc_Cocinas[4]= 108.47;
   		PreProduc_Cocinas[5]= 120.89;
   		
   		 PreProduc_Ollas=new double[6];
   		PreProduc_Ollas[0]= 70.51;
   		PreProduc_Ollas[1]= 80.32;
   		PreProduc_Ollas[2]= 90.14;
   		PreProduc_Ollas[3]= 100.35;
   		PreProduc_Ollas[4]= 108.48;
   		PreProduc_Ollas[5]= 120.83;
   		
   	
   		/*Codigo del producto*/
   		
   			 CodProduc_Tostadoras=new int[8];
   			CodProduc_Tostadoras[0]= 1101;
   			CodProduc_Tostadoras[1]= 1111;
   			CodProduc_Tostadoras[2]= 1121;
   			CodProduc_Tostadoras[3]= 1131;
   			CodProduc_Tostadoras[4]= 1141;
   			CodProduc_Tostadoras[5]= 1151;
   			CodProduc_Tostadoras[6]= 1161;
   			CodProduc_Tostadoras[7]= 1171;
   			
   			 CodProduc_Planchas=new int[8];
   			CodProduc_Planchas[0]= 2202;
   			CodProduc_Planchas[1]= 2212;
   			CodProduc_Planchas[2]= 2222;
   			CodProduc_Planchas[3]= 2232;
   			CodProduc_Planchas[4]= 2242;
   			CodProduc_Planchas[5]= 2252;
   			CodProduc_Planchas[6]= 2262;
   			CodProduc_Planchas[7]= 2272;
   			
   			 CodProduc_Lavadoras=new int[8];
   			CodProduc_Lavadoras[0]= 3303;
   			CodProduc_Lavadoras[1]= 3313;
   			CodProduc_Lavadoras[2]= 3323;
   			CodProduc_Lavadoras[3]= 3333;
   			CodProduc_Lavadoras[4]= 3343;
   			CodProduc_Lavadoras[5]= 3353;
   			CodProduc_Lavadoras[6]= 3363;
   			CodProduc_Lavadoras[7]= 3373;
   		
   			 CodProduc_Licuadoras=new int[8];
   			CodProduc_Licuadoras[0]= 4404;
   			CodProduc_Licuadoras[1]= 4414;
   			CodProduc_Licuadoras[2]= 4424;
   			CodProduc_Licuadoras[3]= 4434;
   			CodProduc_Licuadoras[4]= 4444;
   			CodProduc_Licuadoras[5]= 4454;
   			CodProduc_Licuadoras[6]= 4464;
   			CodProduc_Licuadoras[7]= 4474;
   			
   			 CodProduc_Microondas=new int[8];
   			CodProduc_Microondas[0]= 5505;
   			CodProduc_Microondas[1]= 5515;
   			CodProduc_Microondas[2]= 5525;
   			CodProduc_Microondas[3]= 5535;
   			CodProduc_Microondas[4]= 5545;
   			CodProduc_Microondas[5]= 5555;
   			CodProduc_Microondas[6]= 5565;
   			CodProduc_Microondas[7]= 5575;
   			
   			 CodProduc_Refrigeradoras=new int[8];
   			CodProduc_Refrigeradoras[0]= 6606;
   			CodProduc_Refrigeradoras[1]= 6616;
   			CodProduc_Refrigeradoras[2]= 6626;
   			CodProduc_Refrigeradoras[3]= 6636;
   			CodProduc_Refrigeradoras[4]= 6646;
   			CodProduc_Refrigeradoras[5]= 6656;
   			CodProduc_Refrigeradoras[6]= 6666;
   			CodProduc_Refrigeradoras[7]= 6676;
   			
   			 CodProduc_Cocinas=new int[8];
   			CodProduc_Cocinas[0]= 7707;
   			CodProduc_Cocinas[1]= 7717;
   			CodProduc_Cocinas[2]= 7727;
   			CodProduc_Cocinas[3]= 7737;
   			CodProduc_Cocinas[4]= 7747;
   			CodProduc_Cocinas[5]= 7757;
   			CodProduc_Cocinas[6]= 7767;
   			CodProduc_Cocinas[7]= 7777;
   			
   			 CodProduc_Ollas=new int[8];
   			CodProduc_Ollas[0]= 8808;
   			CodProduc_Ollas[1]= 8818;
   			CodProduc_Ollas[2]= 8828;
   			CodProduc_Ollas[3]= 8838;
   			CodProduc_Ollas[4]= 8848;
   			CodProduc_Ollas[5]= 8858;
   			CodProduc_Ollas[6]= 8868;
   			CodProduc_Ollas[7]= 8878;
   			
   		
   		
   			
   			/*Marcas*/
   			
   			ImMarca_Tostadoras=new String[6];
   			ImMarca_Tostadoras[0]="LG";
   			ImMarca_Tostadoras[1]="Samsung";
   			ImMarca_Tostadoras[2]="Beko";
   			ImMarca_Tostadoras[3]="Electrolux";
   			ImMarca_Tostadoras[4]="Bosch";
   			ImMarca_Tostadoras[5]="Sony";
   			
   		
   			ImMarca_Planchas=new String[6];
   			ImMarca_Planchas[0]="LG";
   			ImMarca_Planchas[1]="Samsung";
   			ImMarca_Planchas[2]="Beko";
   			ImMarca_Planchas[3]="Electrolux";
   			ImMarca_Planchas[4]="Bosch";
   			ImMarca_Planchas[5]="Sony";
   			
   			
   			ImMarca_Lavadoras=new String[6];
   			ImMarca_Lavadoras[0]="LG";
   			ImMarca_Lavadoras[1]="Samsung";                              
   			ImMarca_Lavadoras[2]="Beko";
   			ImMarca_Lavadoras[3]="Electrolux";
   			ImMarca_Lavadoras[4]="Bosch";
   			ImMarca_Lavadoras[5]="Sony";
   			
   			
   			ImMarca_Licuadoras=new String[6];
   			ImMarca_Licuadoras[0]="LG";
   			ImMarca_Licuadoras[1]="Samsung";
   			ImMarca_Licuadoras[2]="Beko";
   			ImMarca_Licuadoras[3]="Electroluc";
   			ImMarca_Licuadoras[4]="Bosch";
   			ImMarca_Licuadoras[5]="Sony";
   		
   			
   			ImMarca_Microondas=new String[6];
   			ImMarca_Microondas[0]="LG";
   			ImMarca_Microondas[1]="Samsung";
   			ImMarca_Microondas[2]="Beko";
   			ImMarca_Microondas[3]="Electrolux";
   			ImMarca_Microondas[4]="Bosch";
   			ImMarca_Microondas[5]="Sony";
   			
   		
   			ImMarca_Refrigeradoras=new String[6];
   			ImMarca_Refrigeradoras[0]="LG";
   			ImMarca_Refrigeradoras[1]="Samsung";
   			ImMarca_Refrigeradoras[2]="Beko";
   			ImMarca_Refrigeradoras[3]="Electrolux";
   			ImMarca_Refrigeradoras[4]="Bosch";
   			ImMarca_Refrigeradoras[5]="Sony";
   			
   			ImMarca_Cocinas=new String[6];
   			ImMarca_Cocinas[0]="LG";
   			ImMarca_Cocinas[1]="Samsung";
   			ImMarca_Cocinas[2]="Beko";
   			ImMarca_Cocinas[3]="Electrolux";
   			ImMarca_Cocinas[4]="Bosch";
   			ImMarca_Cocinas[5]="Sony";
   			
   		
   			ImMarca_Ollas=new String[6];
   			ImMarca_Ollas[0]="LG";
   			ImMarca_Ollas[1]="Samsung";
   			ImMarca_Ollas[2]="Beko";
   			ImMarca_Ollas[3]="Electrolux";
   			ImMarca_Ollas[4]="Bosch";
   			ImMarca_Ollas[5]="Sony";
   		
   			
   			
	}
	void Calculo(){
      
		switch(produc){
		case 0:
			Tostadoras();
			
          break;
 
		case 1:
			Planchas();
			break;
		case 2:
			Lavadoras();
			break;
		case 3: 
		Licuadoras();
		   break;
		case 4:
			Microondas();
			break;
		case 5: 
			 Refrigeradoras();	
			 break;
		case 6: 
			Cocinas();
			break;
		case 7: 
			Ollas();
			break;
		}
		
	}
	
    void Tostadoras(){
    	
	switch(marca){
	case 0: 
	    precio=PreProduc_Tostadoras[0];
		codigo=CodProduc_Tostadoras[0];
		ImMarca= ImMarca_Tostadoras[0];
		
       break;
	case 1: 
		precio=PreProduc_Tostadoras[1];
		codigo=CodProduc_Tostadoras[1];
		ImMarca= ImMarca_Tostadoras[1];

	    break;
	case 2: 
		precio=PreProduc_Tostadoras[2];
		codigo=CodProduc_Tostadoras[2];
		ImMarca= ImMarca_Tostadoras[2];
	
	   break;
	case 3: 
		precio=PreProduc_Tostadoras[3];
		codigo=CodProduc_Tostadoras[3];
		ImMarca= ImMarca_Tostadoras[3];
	break;
	case 4:
		precio=PreProduc_Tostadoras[4]; 
		codigo=CodProduc_Tostadoras[4];
		ImMarca= ImMarca_Tostadoras[4];
		break;
	case 5: 
		precio=PreProduc_Tostadoras[5];
		codigo=CodProduc_Tostadoras[5];
		ImMarca= ImMarca_Tostadoras[5];
		break;
	}
	 
	 }

	void Planchas(){
		switch(marca){
		case 0: 
			precio=PreProduc_Planchas[0];
			codigo=CodProduc_Planchas[0];
			ImMarca= ImMarca_Planchas[0];
           break;
		case 1: 
			precio=PreProduc_Planchas[1];
			codigo=CodProduc_Planchas[1];
			ImMarca= ImMarca_Planchas[1];
		    break;
		case 2: 
			precio=PreProduc_Planchas[2];
			codigo=CodProduc_Planchas[2];
			ImMarca= ImMarca_Planchas[2];
		   break;
		case 3: 
			precio=PreProduc_Planchas[3];
			codigo=CodProduc_Planchas[3];
			ImMarca= ImMarca_Planchas[3];
		  break;
		case 4:
			precio=PreProduc_Planchas[4]; 
			codigo=CodProduc_Planchas[4];
			ImMarca= ImMarca_Planchas[4];
			break;
		case 5: 
			precio=PreProduc_Planchas[5];
			codigo=CodProduc_Planchas[5];
			ImMarca= ImMarca_Planchas[5];
			break;
		}
		
	}
	void Lavadoras(){
		
		switch(marca){
		case 0: 
			precio=PreProduc_Lavadoras[0];
			codigo=CodProduc_Lavadoras[0];
			ImMarca= ImMarca_Lavadoras[0];
           break;
		case 1: 
			precio=PreProduc_Lavadoras[1];
			codigo=CodProduc_Lavadoras[1];
			ImMarca= ImMarca_Lavadoras[1];
           break;
		case 2: 
			precio=PreProduc_Lavadoras[2];
			codigo=CodProduc_Lavadoras[2];
			ImMarca= ImMarca_Lavadoras[2];
           break;
		case 3: 
			precio=PreProduc_Lavadoras[3];
			codigo=CodProduc_Lavadoras[3];
			ImMarca= ImMarca_Lavadoras[3];
           break;
		case 4: 
			precio=PreProduc_Lavadoras[4];
			codigo=CodProduc_Lavadoras[4];
			ImMarca= ImMarca_Lavadoras[4];
           break;
		case 5: 
			precio=PreProduc_Lavadoras[5];
			codigo=CodProduc_Lavadoras[5];
			ImMarca= ImMarca_Lavadoras[5];
           break;
        
		}
		
	}
	void Licuadoras(){
		switch(marca){
		case 0: 
			precio=PreProduc_Licuadoras[0];
			codigo=CodProduc_Licuadoras[0];
			ImMarca= ImMarca_Licuadoras[0];
			
           break;
		case 1: 
			precio=PreProduc_Licuadoras[1];
			codigo=CodProduc_Licuadoras[1];
			ImMarca= ImMarca_Licuadoras[1];
           break;
		case 2: 
			precio=PreProduc_Licuadoras[2];
			codigo=CodProduc_Licuadoras[2];
			ImMarca= ImMarca_Licuadoras[2];
			
           break;
		case 3: 
			precio=PreProduc_Licuadoras[3];
			codigo=CodProduc_Licuadoras[3];
			ImMarca= ImMarca_Licuadoras[3];
			
           break;
		case 4: 
			precio=PreProduc_Licuadoras[4];
			codigo=CodProduc_Licuadoras[4];
			ImMarca= ImMarca_Licuadoras[4];
			
           break;
		case 5: 
			precio=PreProduc_Licuadoras[5];
			codigo=CodProduc_Licuadoras[5];
			ImMarca= ImMarca_Licuadoras[5];
			
           break;   
		}
		
	}
	void Microondas(){
		switch(marca){
		case 0: 
			precio=PreProduc_Microondas[0];
			codigo=CodProduc_Microondas[0];
			ImMarca= ImMarca_Microondas[0];
           break;
		case 1: 
			precio=PreProduc_Microondas[1];
			codigo=CodProduc_Microondas[1];
			ImMarca= ImMarca_Microondas[1];
           break;
		case 2: 
			precio=PreProduc_Microondas[2];
			codigo=CodProduc_Microondas[2];
			ImMarca= ImMarca_Microondas[2];
           break;
		case 3: 
			precio=PreProduc_Microondas[3];
			codigo=CodProduc_Microondas[3];
			ImMarca= ImMarca_Microondas[3];
           break;
		case 4: 
			precio=PreProduc_Microondas[4];
			codigo=CodProduc_Microondas[4];
			ImMarca= ImMarca_Microondas[4];
           break;
		case 5: 
			precio=PreProduc_Microondas[5];
			codigo=CodProduc_Microondas[5];
			ImMarca= ImMarca_Microondas[5];
           break;
		}
	}
	void Refrigeradoras(){
		 switch(marca){
			case 0: 
				precio=PreProduc_Refrigeradoras[0];
				codigo=CodProduc_Refrigeradoras[0];
				ImMarca=ImMarca_Refrigeradoras[0];
               break;
			case 1: 
				precio=PreProduc_Refrigeradoras[1];
				codigo=CodProduc_Refrigeradoras[1];
				ImMarca=ImMarca_Refrigeradoras[1];
               break;
			case 2: 
				precio=PreProduc_Refrigeradoras[2];
				codigo=CodProduc_Refrigeradoras[2];
				ImMarca=ImMarca_Refrigeradoras[2];
               break;
			case 3: 
				precio=PreProduc_Refrigeradoras[3];
				codigo=CodProduc_Refrigeradoras[3];
				ImMarca=ImMarca_Refrigeradoras[3];
               break;
			case 4: 
				precio=PreProduc_Refrigeradoras[4];
				codigo=CodProduc_Refrigeradoras[4];
				ImMarca=ImMarca_Refrigeradoras[4];
               break;
			case 5: 
				precio=PreProduc_Refrigeradoras[5];
				codigo=CodProduc_Refrigeradoras[5];
				ImMarca=ImMarca_Refrigeradoras[5];
               break;   

			}
			
	}
	void Cocinas(){
		switch(marca){
			case 0: 
				precio=PreProduc_Cocinas[0];
				codigo=CodProduc_Cocinas[0];
				ImMarca= ImMarca_Cocinas[0];
              break;
			case 1: 
				precio=PreProduc_Cocinas[1];
				codigo=CodProduc_Cocinas[1];
				ImMarca= ImMarca_Cocinas[1];
              break;
			case 2: 
				precio=PreProduc_Cocinas[2];
				codigo=CodProduc_Cocinas[2];
				ImMarca= ImMarca_Cocinas[2];
              break;
			case 3: 
				precio=PreProduc_Cocinas[3];
				codigo=CodProduc_Cocinas[3];
				ImMarca= ImMarca_Cocinas[3];
              break;
			case 4: 
				precio=PreProduc_Cocinas[4];
				codigo=CodProduc_Cocinas[4];
				ImMarca= ImMarca_Cocinas[4];
              break;
			case 5: 
				precio=PreProduc_Cocinas[5];
				codigo=CodProduc_Cocinas[5];
				ImMarca= ImMarca_Cocinas[5];
              break;   

		}			
		
		
	}
	void Ollas(){
		switch(marca){
			case 0: 
				precio=PreProduc_Ollas[0];
				codigo=CodProduc_Ollas[0];
				ImMarca= ImMarca_Ollas[0];
				
              break;
			case 1: 
				precio=PreProduc_Ollas[1];
				codigo=CodProduc_Ollas[1];
				ImMarca= ImMarca_Ollas[1];
				
              break;
			case 2: 
				precio=PreProduc_Ollas[2];
				codigo=CodProduc_Ollas[2];
				ImMarca= ImMarca_Ollas[2];
				
              break;
			case 3: 
				precio=PreProduc_Ollas[3];
				codigo=CodProduc_Ollas[3];
				ImMarca= ImMarca_Ollas[3];
				
              break;
			case 4: 
				precio=PreProduc_Ollas[4];
				codigo=CodProduc_Ollas[4];
				ImMarca= ImMarca_Ollas[4];
				
              break;
			case 5: 
				precio=PreProduc_Ollas[5];
				codigo=CodProduc_Ollas[5];
				ImMarca= ImMarca_Ollas[5];
				
              break;   

		}			
    }
   
	void Equivalencia_Puntos(){
		if(puntos!=0){
			sol=Math.round((puntos*0.1)*100.0)/100.0;
		}
		else  {sol=0;}
		
		
}
    double importePagar(){
    	double ip=0;
    	switch(produc){
    	case 0: 
    		if(precio==PreProduc_Tostadoras[0])
    			ip=cantidad*70.53;
    		else if (precio==PreProduc_Tostadoras[1])
    			ip=cantidad*80.31;
    		else if(precio==PreProduc_Tostadoras[2])
    			ip=cantidad*90.18;
    		else if (precio==PreProduc_Tostadoras[3])
    			ip=cantidad*100.36;
    		else if(precio==PreProduc_Tostadoras[4])
    			ip=cantidad*108.44;
    		else if (precio==PreProduc_Tostadoras[5])
    			ip=cantidad*120.81;

    			 break;
    	case 1:
    		if(precio==PreProduc_Planchas[0])
    			ip=cantidad*70.55;
    		else if (precio==PreProduc_Planchas[1])
    			ip=cantidad*80.32;
    		else if(precio==PreProduc_Planchas[2])
    			ip=cantidad*90.18;
    		else if (precio==PreProduc_Planchas[3])
    			ip=cantidad*100.35;
    		else if(precio==PreProduc_Planchas[4])
    			ip=cantidad*108.48;
    		else if (precio==PreProduc_Planchas[5])
    			ip=cantidad*120.89;
    		
    			 break;
    	case 2:
    		if(precio==PreProduc_Lavadoras[0])
    			ip=cantidad*70.54;
    		else if (precio==PreProduc_Lavadoras[1])
    			ip=cantidad*80.31;
    		else if(precio==PreProduc_Lavadoras[2])
    			ip=cantidad*90.17;
    		else if (precio==PreProduc_Lavadoras[3])
    			ip=cantidad*100.32;
    		else if(precio==PreProduc_Lavadoras[4])
    			ip=cantidad*108.47;
    		else if (precio==PreProduc_Lavadoras[5])
    			ip=cantidad*120.84;
    			
    	case 3:
    		if(precio==PreProduc_Licuadoras[0])
    			ip=cantidad*70.55;
    		else if (precio==PreProduc_Licuadoras[1])
    			ip=cantidad*80.32;
    		else if(precio==PreProduc_Licuadoras[2])
    			ip=cantidad*90.18;
    		else if (precio==PreProduc_Licuadoras[3])
    			ip=cantidad*100.35;
    		else if(precio==PreProduc_Licuadoras[4])
    			ip=cantidad*108.48;
    		else if (precio==PreProduc_Licuadoras[5])
    			ip=cantidad*120.89;
    		
    			 break;
    	case 4:
    		if(precio==PreProduc_Microondas[0])
    			ip=cantidad*70.55;
    		else if (precio==PreProduc_Microondas[1])
    			ip=cantidad*80.32;
    		else if(precio==PreProduc_Microondas[2])
    			ip=cantidad*90.18;
    		else if (precio==PreProduc_Microondas[3])
    			ip=cantidad*100.35;
    		else if(precio==PreProduc_Microondas[4])
    			ip=cantidad*108.48;
    		else if (precio==PreProduc_Microondas[5])
    			ip=cantidad*120.89;
    		
    			 break;
    	case 5:
    		if(precio==PreProduc_Refrigeradoras[0])
    			ip=cantidad*70.55;
    		else if (precio==PreProduc_Refrigeradoras[1])
    			ip=cantidad*80.32;
    		else if(precio==PreProduc_Refrigeradoras[2])
    			ip=cantidad*90.18;
    		else if (precio==PreProduc_Refrigeradoras[3])
    			ip=cantidad*100.35;
    		else if(precio==PreProduc_Refrigeradoras[4])
    			ip=cantidad*108.48;
    		else if (precio==PreProduc_Refrigeradoras[5])
    			ip=cantidad*120.89;
    		
    			 break;
    	case 6:
    		if(precio==PreProduc_Cocinas[0])
    			ip=cantidad*70.55;
    		else if (precio==PreProduc_Cocinas[1])
    			ip=cantidad*80.32;
    		else if(precio==PreProduc_Cocinas[2])
    			ip=cantidad*90.18;
    		else if (precio==PreProduc_Cocinas[3])
    			ip=cantidad*100.35;
    		else if(precio==PreProduc_Cocinas[4])
    			ip=cantidad*108.48;
    		else if (precio==PreProduc_Cocinas[5])
    			ip=cantidad*120.89;
    		
    			 break;
    	case 7:
    		if(precio==PreProduc_Ollas[0])
    			ip=cantidad*70.55;
    		else if (precio==PreProduc_Ollas[1])
    			ip=cantidad*80.32;
    		else if(precio==PreProduc_Ollas[2])
    			ip=cantidad*90.18;
    		else if (precio==PreProduc_Ollas[3])
    			ip=cantidad*100.35;
    		else if(precio==PreProduc_Ollas[4])
    			ip=cantidad*108.48;
    		else if (precio==PreProduc_Ollas[5])
    			ip=cantidad*120.89;
    		
    			 break;
    	}
  
    	return ip;
    }
	
    String AgregarLineaVenta(){
    	String producto;
    	switch(produc){
		case 0:
			producto="Tostadoras";
			
          break;
 
		case 1:
			producto="Planchas";
			break;
		case 2:
			producto="Lavadoras";
			break;
		case 3: 
			producto="Licuadoras";
		   break;
		case 4:
			producto="Microondas";
			break;
		case 5: 
			producto="Refrigeradoras";	
			 break;
		case 6: 
			producto="Cocinas";
			break;
		case 7: 
			producto="Ollas";
			break;
			default: producto="No definido";
		}
    	iTotal+=Math.round((precio*cantidad-sol) * 100.0) / 100.0;
    	
    	return producto+":\t"+"   "+"  "+ImMarca+"\t"+"   "+cantidad+"\t"+"#"+codigo+"\t"+precio+"\t"+sol+"\t"+Math.round((precio*cantidad-sol) * 100.0) / 100.0+"\n";
    	
    	
    	
    	
    }
	
    void Imprimir(String Linea){
    	
    	//Lineas=Lineas+AgregarLineaVenta();
    	txtProceso.setText("Fecha:\t"+fecha+"\n");
    	txtProceso.append("-------------------------------------------------------------------BOLETA DE PAGO----------------------------------------------------------"+"\n");
    	txtProceso.append("  "+"PRODUCTO:\t"+"     "+"MARCA:\t"+"   "+"CANTIDAD:\t"+"CODIGO:\t"+"PRECIO U.:\t"+"PUNTOS S/."+"\t"+"PRECIO T S/."+"\n");
    	txtProceso.append("======================================================================================"+"\n");
    	txtProceso.append(Linea);
		txtProceso.append("-------------------------------------------------------------------------------------------------------------------------------------------------------\n");
		txtProceso.append("Importe Total\t\t\t\t\t\t "  + Math.round((iTotal) * 100.0) / 100.0);
		
	
	
	
    }

	void Procesar(){
		
		leeDatos();		
		Calculo();	
		Equivalencia_Puntos();
		Lineas+=AgregarLineaVenta();
		Imprimir(Lineas);
	
	}
	void limpiar(){
		cboProductos.setSelectedIndex(-1);
		cboMarcas.setSelectedIndex(-1);
		txtCantidad.setText(null);
		txtPuntos.setText(null);
		txtFecha.setText(null);
		txtProceso.setText(null);
		cboProductos.requestFocus();
		Lineas="";
		iTotal=0;
		
		
	}
	
	
	

}

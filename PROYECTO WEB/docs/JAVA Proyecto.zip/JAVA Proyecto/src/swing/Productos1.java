package swing;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.lang.NullPointerException;
import java.awt.Toolkit;
public class Productos1 extends JFrame {

	private JPanel contentPane;
	private JLabel lblNewLabel;
	private JLabel lblPrecio;
	private JLabel lblCodigo;
	private JLabel lblCantidad;
	private JLabel lblMarca;
	private JTextField txtPrecio;
	private JTextField txtCodigo;
	private JTextField txtCantidad;
	private JComboBox cboMarcas;
	private JComboBox cboProductos;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Productos1 frame = new Productos1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Productos1() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setIconImage(Toolkit.getDefaultToolkit().getImage(Productos1.class.getResource("/iconos32/innovacion.png")));
		setResizable(false);
		setTitle("Productos");
		setBounds(100, 100, 445, 410);
		getContentPane().setLayout(null);
		setLocationRelativeTo(null);
		
		lblMarca = new JLabel("MARCA");
		lblMarca.setBounds(352, 21, 67, 26);
		getContentPane().add(lblMarca);
		lblMarca.setForeground(Color.BLUE);
		
		lblNewLabel = new JLabel("PRODUCTOS");
		lblNewLabel.setBounds(10, 21, 90, 26);
		getContentPane().add(lblNewLabel);
		lblNewLabel.setForeground(Color.BLUE);
		
		cboProductos = new JComboBox();
		cboProductos.setBounds(10, 59, 97, 37);
		getContentPane().add(cboProductos);
		cboProductos.setModel(new DefaultComboBoxModel(new String[] {"Tostadoras", "Planchas", "Lavadoras", "Licuadoras", "Microondas", "Refrigeradoras", "Cocinas", "Ollas "}));
		
		JButton button = new JButton("REGRESAR");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				TiendaElectronica();
			}

			private void setVisible(boolean b) {
				// TODO Auto-generated method stub
				
			}
		});
		button.setIcon(new ImageIcon(Productos1.class.getResource("/iconos32/carpeta.png")));
		button.setBounds(10, 319, 144, 41);
		getContentPane().add(button);
		
		cboMarcas = new JComboBox();
		cboMarcas.setModel(new DefaultComboBoxModel(new String[] {"LG", "Samsung", "Beko", "Electrolux", "Bosch", "Sony"}));
		cboMarcas.setBounds(322, 59, 97, 37);
		getContentPane().add(cboMarcas);
		
		JLabel lblNewLabel_1 = new JLabel("");
		
		lblNewLabel_1.setBounds(110, 11, 209, 182);
		ImageIcon ico=new ImageIcon(getClass().getResource("conjunto-concepto-elementos-domesticos-electrodomesticos-equipo-cocina-productos-digitales-composicion-cuadrada-ilustracion-vectorial-plana_98292-2096.jpg"));
		ImageIcon img=new ImageIcon(ico.getImage().getScaledInstance(lblNewLabel_1.getWidth(), lblNewLabel_1.getHeight(),Image.SCALE_SMOOTH));
		lblNewLabel_1.setIcon(img);
		getContentPane().add(lblNewLabel_1);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 195, 409, 119);
		getContentPane().add(panel);
		panel.setLayout(null);
		
		lblPrecio = new JLabel("PRECIO");
		lblPrecio.setForeground(Color.BLUE);
		lblPrecio.setBounds(31, 11, 67, 26);
		panel.add(lblPrecio);
		
		lblCodigo = new JLabel("CODIGO");
		lblCodigo.setForeground(Color.BLUE);
		lblCodigo.setBounds(178, 42, 67, 26);
		panel.add(lblCodigo);
		
		lblCantidad = new JLabel("CANTIDAD");
		lblCantidad.setForeground(Color.BLUE);
		lblCantidad.setBounds(314, 11, 67, 26);
		panel.add(lblCantidad);
		
		txtPrecio = new JTextField();
		txtPrecio.setColumns(10);
		txtPrecio.setBounds(12, 45, 86, 36);
		panel.add(txtPrecio);
		
		txtCodigo = new JTextField();
		txtCodigo.setColumns(10);
		txtCodigo.setBounds(159, 72, 86, 36);
		panel.add(txtCodigo);
		
		txtCantidad = new JTextField();
		txtCantidad.setColumns(10);
		txtCantidad.setBounds(294, 42, 86, 36);
		panel.add(txtCantidad);
		
		
		
		JButton button_1 = new JButton("");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				limpiar();
			}
		});
		button_1.setIcon(new ImageIcon(Productos1.class.getResource("/iconos32/add-file.png")));
		button_1.setBounds(364, 319, 55, 41);
		getContentPane().add(button_1);
		
		JButton button_2 = new JButton("");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Procesar();
			}
		});
		button_2.setIcon(new ImageIcon(Productos1.class.getResource("/iconos32/proceso-automatizado.png")));
		button_2.setBounds(299, 319, 55, 41);
		getContentPane().add(button_2);
		
	}
	void TiendaElectronica(){
		this.setVisible(false);
		ProyectoTiendaElectronica PTE= new ProyectoTiendaElectronica();
		PTE.setVisible(true);
	}
	
	int cant,produc,marca,codigo;
	double precio;
	
	double[] PreProduc_Tostadoras;
	int [] CodProduc_Tostadoras;
	int [] LisCant_Tostadoras;
	
	double[] PreProduc_Planchas;
	int [] CodProduc_Planchas;
	int [] LisCant_Planchas;
	
	double[] PreProduc_Lavadoras;
	int [] CodProduc_Lavadoras;
	int [] LisCant_Lavadoras;
	
	double[] PreProduc_Licuadoras;
	int [] CodProduc_Licuadoras;
	int [] LisCant_Licuadoras;
	
	double[] PreProduc_Microondas;
	int [] CodProduc_Microondas;
	int [] LisCant_Microondas;
	
	double[] PreProduc_Refrigeradoras;
	int [] CodProduc_Refrigeradoras;
	int [] LisCant_Refrigeradoras;
	
	double[] PreProduc_Cocinas;
	int [] CodProduc_Cocinas;
	int [] LisCant_Cocinas;
	
	double[] PreProduc_Ollas;
	int [] CodProduc_Ollas;
	int [] LisCant_Ollas;
	
	
	
	
	void leeDatos(){
       produc=cboProductos.getSelectedIndex();
       marca=cboMarcas.getSelectedIndex();
       
   	
   		 PreProduc_Tostadoras=new double[6];
   		PreProduc_Tostadoras[0]= 70.53;
   		PreProduc_Tostadoras[1]= 75.31;
   		PreProduc_Tostadoras[2]= 80.18;
   		PreProduc_Tostadoras[3]= 85.36;
   		PreProduc_Tostadoras[4]= 90.44;
   		PreProduc_Tostadoras[5]= 95.81;
   		
   		 PreProduc_Planchas=new double[6];
   		PreProduc_Planchas[0]= 80.55;
   		PreProduc_Planchas[1]= 85.32;
   		PreProduc_Planchas[2]= 90.18;
   		PreProduc_Planchas[3]= 95.35;
   		PreProduc_Planchas[4]= 100.48;
   		PreProduc_Planchas[5]= 105.89;
   		
   		 PreProduc_Lavadoras=new double[6];
   		PreProduc_Lavadoras[0]= 1000.54;
   		PreProduc_Lavadoras[1]= 1050.31;
   		PreProduc_Lavadoras[2]= 1100.17;
   		PreProduc_Lavadoras[3]= 1150.32;
   		PreProduc_Lavadoras[4]= 1200.47;
   		PreProduc_Lavadoras[5]= 1250.84;
   		
   		 PreProduc_Licuadoras=new double[6];
   		PreProduc_Licuadoras[0]= 150.55;
   		PreProduc_Licuadoras[1]= 160.37;
   		PreProduc_Licuadoras[2]= 170.11;
   		PreProduc_Licuadoras[3]= 180.32;
   		PreProduc_Licuadoras[4]= 190.49;
   		PreProduc_Licuadoras[5]= 200.83;
   		
   		 PreProduc_Microondas=new double[6];
   		PreProduc_Microondas[0]= 250.55;
   		PreProduc_Microondas[1]= 270.37;
   		PreProduc_Microondas[2]= 290.18;
   		PreProduc_Microondas[3]= 310.33;
   		PreProduc_Microondas[4]= 330.41;
   		PreProduc_Microondas[5]= 350.87;
   		
   		 PreProduc_Refrigeradoras=new double[6];
   		PreProduc_Refrigeradoras[0]= 1800.52;
   		PreProduc_Refrigeradoras[1]= 2200.33;
   		PreProduc_Refrigeradoras[2]= 2600.14;
   		PreProduc_Refrigeradoras[3]= 3000.31;
   		PreProduc_Refrigeradoras[4]= 3400.48;
   		PreProduc_Refrigeradoras[5]= 3800.82;
   		
   		 PreProduc_Cocinas=new double[6];
   		PreProduc_Cocinas[0]= 1000.53;
   		PreProduc_Cocinas[1]= 1200.37;
   		PreProduc_Cocinas[2]= 1400.14;
   		PreProduc_Cocinas[3]= 1600.36;
   		PreProduc_Cocinas[4]= 1800.47;
   		PreProduc_Cocinas[5]= 2000.89;
   		
   		 PreProduc_Ollas=new double[6];
   		PreProduc_Ollas[0]= 90.51;
   		PreProduc_Ollas[1]= 100.32;
   		PreProduc_Ollas[2]= 115.14;
   		PreProduc_Ollas[3]= 120.35;
   		PreProduc_Ollas[4]= 130.48;
   		PreProduc_Ollas[5]= 135.83;
   		
   		
   		
   		
   			 CodProduc_Tostadoras=new int[8];
   			CodProduc_Tostadoras[0]= 1101;
   			CodProduc_Tostadoras[1]= 1111;
   			CodProduc_Tostadoras[2]= 1121;
   			CodProduc_Tostadoras[3]= 1131;
   			CodProduc_Tostadoras[4]= 1141;
   			CodProduc_Tostadoras[5]= 1151;
   			CodProduc_Tostadoras[6]= 1161;
   			CodProduc_Tostadoras[7]= 1171;
   			
   			 CodProduc_Planchas=new int[8];
   			CodProduc_Planchas[0]= 2202;
   			CodProduc_Planchas[1]= 2212;
   			CodProduc_Planchas[2]= 2222;
   			CodProduc_Planchas[3]= 2232;
   			CodProduc_Planchas[4]= 2242;
   			CodProduc_Planchas[5]= 2252;
   			CodProduc_Planchas[6]= 2262;
   			CodProduc_Planchas[7]= 2272;
   			
   			 CodProduc_Lavadoras=new int[8];
   			CodProduc_Lavadoras[0]= 3303;
   			CodProduc_Lavadoras[1]= 3313;
   			CodProduc_Lavadoras[2]= 3323;
   			CodProduc_Lavadoras[3]= 3333;
   			CodProduc_Lavadoras[4]= 3343;
   			CodProduc_Lavadoras[5]= 3353;
   			CodProduc_Lavadoras[6]= 3363;
   			CodProduc_Lavadoras[7]= 3373;
   		
   			 CodProduc_Licuadoras=new int[8];
   			CodProduc_Licuadoras[0]= 4404;
   			CodProduc_Licuadoras[1]= 4414;
   			CodProduc_Licuadoras[2]= 4424;
   			CodProduc_Licuadoras[3]= 4434;
   			CodProduc_Licuadoras[4]= 4444;
   			CodProduc_Licuadoras[5]= 4454;
   			CodProduc_Licuadoras[6]= 4464;
   			CodProduc_Licuadoras[7]= 4474;
   			
   			 CodProduc_Microondas=new int[8];
   			CodProduc_Microondas[0]= 5505;
   			CodProduc_Microondas[1]= 5515;
   			CodProduc_Microondas[2]= 5525;
   			CodProduc_Microondas[3]= 5535;
   			CodProduc_Microondas[4]= 5545;
   			CodProduc_Microondas[5]= 5555;
   			CodProduc_Microondas[6]= 5565;
   			CodProduc_Microondas[7]= 5575;
   			
   			 CodProduc_Refrigeradoras=new int[8];
   			CodProduc_Refrigeradoras[0]= 6606;
   			CodProduc_Refrigeradoras[1]= 6616;
   			CodProduc_Refrigeradoras[2]= 6626;
   			CodProduc_Refrigeradoras[3]= 6636;
   			CodProduc_Refrigeradoras[4]= 6646;
   			CodProduc_Refrigeradoras[5]= 6656;
   			CodProduc_Refrigeradoras[6]= 6666;
   			CodProduc_Refrigeradoras[7]= 6676;
   			
   			 CodProduc_Cocinas=new int[8];
   			CodProduc_Cocinas[0]= 7707;
   			CodProduc_Cocinas[1]= 7717;
   			CodProduc_Cocinas[2]= 7727;
   			CodProduc_Cocinas[3]= 7737;
   			CodProduc_Cocinas[4]= 7747;
   			CodProduc_Cocinas[5]= 7757;
   			CodProduc_Cocinas[6]= 7767;
   			CodProduc_Cocinas[7]= 7777;
   			
   			 CodProduc_Ollas=new int[8];
   			CodProduc_Ollas[0]= 8808;
   			CodProduc_Ollas[1]= 8818;
   			CodProduc_Ollas[2]= 8828;
   			CodProduc_Ollas[3]= 8838;
   			CodProduc_Ollas[4]= 8848;
   			CodProduc_Ollas[5]= 8858;
   			CodProduc_Ollas[6]= 8868;
   			CodProduc_Ollas[7]= 8878;
   			
   		
   		
   			 LisCant_Tostadoras=new int[8];
   			
   			LisCant_Tostadoras[0]= 35;
   			LisCant_Tostadoras[1]= 40;
   			LisCant_Tostadoras[2]= 45;
   			LisCant_Tostadoras[3]= 50;
   			LisCant_Tostadoras[4]= 55;
   			LisCant_Tostadoras[5]= 60;
   			LisCant_Tostadoras[6]= 65;
   			LisCant_Tostadoras[7]= 70;
   			
   			 LisCant_Planchas=new int[8];
   			LisCant_Planchas[0]= 70;
   			LisCant_Planchas[1]= 65;
   			LisCant_Planchas[2]= 60;
   			LisCant_Planchas[3]= 55;
   			LisCant_Planchas[4]= 50;
   			LisCant_Planchas[5]= 45;
   			LisCant_Planchas[6]= 40;
   			LisCant_Planchas[7]= 35;
   			
   			 LisCant_Lavadoras=new int[8];
   			LisCant_Lavadoras[0]= 40;
   			LisCant_Lavadoras[1]= 45;
   			LisCant_Lavadoras[2]= 50;
   			LisCant_Lavadoras[3]= 55;
   			LisCant_Lavadoras[4]= 60;
   			LisCant_Lavadoras[5]= 65;
   			LisCant_Lavadoras[6]= 70;
   			LisCant_Lavadoras[7]= 35;
   		
   			 LisCant_Licuadoras=new int[8];
   			LisCant_Licuadoras[0]= 45;
   			LisCant_Licuadoras[1]= 50;
   			LisCant_Licuadoras[2]= 55;
   			LisCant_Licuadoras[3]= 60;
   			LisCant_Licuadoras[4]= 65;
   			LisCant_Licuadoras[5]= 70;
   			LisCant_Licuadoras[6]= 35;
   			LisCant_Licuadoras[7]= 40;
   			
   			 LisCant_Microondas=new int[8];
   			LisCant_Microondas[0]= 50;
   			LisCant_Microondas[1]= 55;
   			LisCant_Microondas[2]= 60;
   			LisCant_Microondas[3]= 65;
   			LisCant_Microondas[4]= 70;
   			LisCant_Microondas[5]= 35;
   			LisCant_Microondas[6]= 40;
   			LisCant_Microondas[7]= 45;
   			
   			 LisCant_Refrigeradoras=new int[8];
   			LisCant_Refrigeradoras[0]= 55;
   			LisCant_Refrigeradoras[1]= 60;
   			LisCant_Refrigeradoras[2]= 65;
   			LisCant_Refrigeradoras[3]= 70;
   			LisCant_Refrigeradoras[4]= 35;
   			LisCant_Refrigeradoras[5]= 40;
   			LisCant_Refrigeradoras[6]= 45;
   			LisCant_Refrigeradoras[7]= 50;
   			
   			 LisCant_Cocinas=new int[8];
   			LisCant_Cocinas[0]= 60;
   			LisCant_Cocinas[1]= 65;
   			LisCant_Cocinas[2]= 70;
   			LisCant_Cocinas[3]= 35;
   			LisCant_Cocinas[4]= 40;
   			LisCant_Cocinas[5]= 45;
   			LisCant_Cocinas[6]= 50;
   			LisCant_Cocinas[7]= 55;
   			
   			 LisCant_Ollas=new int[8];
   			LisCant_Ollas[0]= 65;
   			LisCant_Ollas[1]= 70;
   			LisCant_Ollas[2]= 35;
   			LisCant_Ollas[3]= 40;
   			LisCant_Ollas[4]= 45;
   			LisCant_Ollas[5]= 50;
   			LisCant_Ollas[6]= 55;
   			LisCant_Ollas[7]= 60;
   			
   			
   		

	}
	void Calculo(){

		
		switch(produc){
		case 0:
			Tostadoras();
          break;
 
		case 1:
			Planchas();
			break;
		case 2:
			Lavadoras();
			break;
		case 3: 
		Licuadoras();
		   break;
		case 4:
			Microondas();
			break;
		case 5: 
			 Refrigeradoras();	
			 break;
		case 6: 
			Cocinas();
			break;
		case 7: 
			Ollas();
			break;
		}
		
	}
	
    void Tostadoras(){

    	
	switch(marca){
	case 0: 
	    precio=PreProduc_Tostadoras[0];
		codigo=CodProduc_Tostadoras[0];
		cant=LisCant_Tostadoras[0];
		
       break;
	case 1: 
		precio=PreProduc_Tostadoras[1];
		codigo=CodProduc_Tostadoras[1];
		cant=LisCant_Tostadoras[1];

	    break;
	case 2: 
		precio=PreProduc_Tostadoras[2];
		codigo=CodProduc_Tostadoras[2];
		cant=LisCant_Tostadoras[2];
	
	   break;
	case 3: 
		precio=PreProduc_Tostadoras[3];
		codigo=CodProduc_Tostadoras[3];
		cant=LisCant_Tostadoras[3];
	break;
	case 4:
		precio=PreProduc_Tostadoras[4]; 
		codigo=CodProduc_Tostadoras[4];
		cant=LisCant_Tostadoras[4];
		break;
	case 5: 
		precio=PreProduc_Tostadoras[5];
		codigo=CodProduc_Tostadoras[5];
		cant=LisCant_Tostadoras[5];
		break;
	}
	 
	 }

	void Planchas(){
		switch(marca){
		case 0: 
			precio=PreProduc_Planchas[0];
			codigo=CodProduc_Planchas[0];
			cant=LisCant_Planchas[0];
           break;
		case 1: 
			precio=PreProduc_Planchas[1];
			codigo=CodProduc_Planchas[1];
			cant=LisCant_Planchas[1];
		    break;
		case 2: 
			precio=PreProduc_Planchas[2];
			codigo=CodProduc_Planchas[2];
			cant=LisCant_Planchas[2];
		   break;
		case 3: 
			precio=PreProduc_Planchas[3];
			codigo=CodProduc_Planchas[3];
			cant=LisCant_Planchas[3];
		  break;
		case 4:
			precio=PreProduc_Planchas[4]; 
			codigo=CodProduc_Planchas[4];
			cant=LisCant_Planchas[4];
			break;
		case 5: 
			precio=PreProduc_Planchas[5];
			codigo=CodProduc_Planchas[5];
			cant=LisCant_Planchas[5];
			break;
		}
		
	}
	void Lavadoras(){
		
		switch(marca){
		case 0: 
			precio=PreProduc_Lavadoras[0];
			codigo=CodProduc_Lavadoras[0];
			cant=LisCant_Lavadoras[0];
           break;
		case 1: 
			precio=PreProduc_Lavadoras[1];
			codigo=CodProduc_Lavadoras[1];
			cant=LisCant_Lavadoras[1];
           break;
		case 2: 
			precio=PreProduc_Lavadoras[2];
			codigo=CodProduc_Lavadoras[2];
			cant=LisCant_Lavadoras[2];
           break;
		case 3: 
			precio=PreProduc_Lavadoras[3];
			codigo=CodProduc_Lavadoras[3];
			cant=LisCant_Lavadoras[3];
           break;
		case 4: 
			precio=PreProduc_Lavadoras[4];
			codigo=CodProduc_Lavadoras[4];
			cant=LisCant_Lavadoras[4];
           break;
		case 5: 
			precio=PreProduc_Lavadoras[5];
			codigo=CodProduc_Lavadoras[5];
			cant=LisCant_Lavadoras[5];
           break;
        
		}
		
	}
	void Licuadoras(){
		switch(marca){
		case 0: 
			precio=PreProduc_Licuadoras[0];
			codigo=CodProduc_Licuadoras[0];
			cant=LisCant_Licuadoras[0];
           break;
		case 1: 
			precio=PreProduc_Licuadoras[1];
			codigo=CodProduc_Licuadoras[1];
			cant=LisCant_Licuadoras[1];
           break;
		case 2: 
			precio=PreProduc_Licuadoras[2];
			codigo=CodProduc_Licuadoras[2];
			cant=LisCant_Licuadoras[2];
           break;
		case 3: 
			precio=PreProduc_Licuadoras[3];
			codigo=CodProduc_Licuadoras[3];
			cant=LisCant_Licuadoras[3];
           break;
		case 4: 
			precio=PreProduc_Licuadoras[4];
			codigo=CodProduc_Licuadoras[4];
			cant=LisCant_Licuadoras[4];
           break;
		case 5: 
			precio=PreProduc_Licuadoras[5];
			codigo=CodProduc_Licuadoras[5];
			cant=LisCant_Licuadoras[5];
           break;   
		}
		
	}
	void Microondas(){
		switch(marca){
		case 0: 
			precio=PreProduc_Microondas[0];
			codigo=CodProduc_Microondas[0];
			cant=LisCant_Microondas[0];
           break;
		case 1: 
			precio=PreProduc_Microondas[1];
			codigo=CodProduc_Microondas[1];
			cant=LisCant_Microondas[1];
           break;
		case 2: 
			precio=PreProduc_Microondas[2];
			codigo=CodProduc_Microondas[2];
			cant=LisCant_Microondas[2];
           break;
		case 3: 
			precio=PreProduc_Microondas[3];
			codigo=CodProduc_Microondas[3];
			cant=LisCant_Microondas[3];
           break;
		case 4: 
			precio=PreProduc_Microondas[4];
			codigo=CodProduc_Microondas[4];
			cant=LisCant_Microondas[4];
           break;
		case 5: 
			precio=PreProduc_Microondas[5];
			codigo=CodProduc_Microondas[5];
			cant=LisCant_Microondas[5];
           break;
		}
	}
	void Refrigeradoras(){
		 switch(marca){
			case 0: 
				precio=PreProduc_Refrigeradoras[0];
				codigo=CodProduc_Refrigeradoras[0];
				cant=LisCant_Refrigeradoras[0];
               break;
			case 1: 
				precio=PreProduc_Refrigeradoras[1];
				codigo=CodProduc_Refrigeradoras[1];
				cant=LisCant_Refrigeradoras[1];
               break;
			case 2: 
				precio=PreProduc_Refrigeradoras[2];
				codigo=CodProduc_Refrigeradoras[2];
				cant=LisCant_Refrigeradoras[2];
               break;
			case 3: 
				precio=PreProduc_Refrigeradoras[3];
				codigo=CodProduc_Refrigeradoras[3];
				cant=LisCant_Refrigeradoras[3];
               break;
			case 4: 
				precio=PreProduc_Refrigeradoras[4];
				codigo=CodProduc_Refrigeradoras[4];
				cant=LisCant_Refrigeradoras[4];
               break;
			case 5: 
				precio=PreProduc_Refrigeradoras[5];
				codigo=CodProduc_Refrigeradoras[5];
				cant=LisCant_Refrigeradoras[5];
               break;   

			}
			
	}
	void Cocinas(){
		switch(marca){
			case 0: 
				precio=PreProduc_Cocinas[0];
				codigo=CodProduc_Cocinas[0];
				cant=LisCant_Cocinas[0];
              break;
			case 1: 
				precio=PreProduc_Cocinas[1];
				codigo=CodProduc_Cocinas[1];
				cant=LisCant_Cocinas[1];
              break;
			case 2: 
				precio=PreProduc_Cocinas[2];
				codigo=CodProduc_Cocinas[2];
				cant=LisCant_Cocinas[2];
              break;
			case 3: 
				precio=PreProduc_Cocinas[3];
				codigo=CodProduc_Cocinas[3];
				cant=LisCant_Cocinas[3];
              break;
			case 4: 
				precio=PreProduc_Cocinas[4];
				codigo=CodProduc_Cocinas[4];
				cant=LisCant_Cocinas[4];
              break;
			case 5: 
				precio=PreProduc_Cocinas[5];
				codigo=CodProduc_Cocinas[5];
				cant=LisCant_Cocinas[5];
              break;   

		}			
		
		
	}
	void Ollas(){
		switch(marca){
			case 0: 
				precio=PreProduc_Ollas[0];
				codigo=CodProduc_Ollas[0];
				cant=LisCant_Ollas[0];
              break;
			case 1: 
				precio=PreProduc_Ollas[1];
				codigo=CodProduc_Ollas[1];
				cant=LisCant_Ollas[1];
              break;
			case 2: 
				precio=PreProduc_Ollas[2];
				codigo=CodProduc_Ollas[2];
				cant=LisCant_Ollas[2];
              break;
			case 3: 
				precio=PreProduc_Ollas[3];
				codigo=CodProduc_Ollas[3];
				cant=LisCant_Ollas[3];
              break;
			case 4: 
				precio=PreProduc_Ollas[4];
				codigo=CodProduc_Ollas[4];
				cant=LisCant_Ollas[4];
              break;
			case 5: 
				precio=PreProduc_Ollas[5];
				codigo=CodProduc_Ollas[5];
				cant=LisCant_Ollas[5];
              break;   

		}			
		
		
	}
	
	void Imprimir(){
		txtPrecio.setText("S/." + precio);
		txtCodigo.setText("#" + codigo);
		txtCantidad.setText("" + cant);
	}
	
	
	
	
	
	void Procesar(){
		
		leeDatos();		
		Calculo();
		Imprimir();
		
		
	}
	void limpiar(){
		cboProductos.setSelectedIndex(-1);
		cboMarcas.setSelectedIndex(-1);
		txtPrecio.setText(null);
		txtCodigo.setText(null);
		txtCantidad.setText(null);
		cboProductos.requestFocus();
		
	}

	

}

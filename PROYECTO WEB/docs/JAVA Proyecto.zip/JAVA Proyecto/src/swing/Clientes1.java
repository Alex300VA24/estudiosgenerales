package swing;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;

public class Clientes1 extends JFrame {

	private JPanel contentPane;
	private JTextField txtCantidad;
	private JTextField txtPuntos;
	private JTextField txtSoles;
	private JTextField txtDolares;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Clientes1 frame = new Clientes1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Clientes1() {
		setResizable(false);
		setIconImage(Toolkit.getDefaultToolkit().getImage(Clientes1.class.getResource("/iconos32/innovacion.png")));
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 445, 505);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		
		setTitle("Clientes");
		setBounds(100, 100, 445, 410);
		getContentPane().setLayout(null);
		contentPane.setLayout(null);
		
		JLabel lblCantidadDeProductos = new JLabel("CANTIDAD DE PRODUCTOS COMPRANDOS:");
		lblCantidadDeProductos.setForeground(Color.BLUE);
		lblCantidadDeProductos.setBounds(10, 11, 263, 26);
		getContentPane().add(lblCantidadDeProductos);
		
		setLocationRelativeTo(null);
		
		
		JButton button = new JButton("REGRESAR");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TiendaElectronica();
			}

			private void setVisible(boolean b) {
				// TODO Auto-generated method stub
				
			}
		});
		button.setIcon(new ImageIcon(Clientes1.class.getResource("/iconos32/carpeta.png")));
		button.setBounds(10, 319, 141, 41);
		getContentPane().add(button);
		
		JButton button_1 = new JButton("");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				limpiar();
			}
		});
		button_1.setIcon(new ImageIcon(Clientes1.class.getResource("/iconos32/add-file.png")));
		button_1.setBounds(364, 319, 55, 41);
		getContentPane().add(button_1);
		
		JButton button_2 = new JButton("");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Procesar();
			}
		});
		button_2.setIcon(new ImageIcon(Clientes1.class.getResource("/iconos32/proceso-automatizado.png")));
		button_2.setBounds(299, 319, 55, 41);
		getContentPane().add(button_2);
		
		JLabel lblNewLabel = new JLabel("");
		
		lblNewLabel.setBounds(10, 165, 409, 143);
		ImageIcon ico=new ImageIcon(getClass().getResource("mejores clientes.jpg"));
		ImageIcon img=new ImageIcon(ico.getImage().getScaledInstance(lblNewLabel.getWidth(), lblNewLabel.getHeight(),Image.SCALE_SMOOTH));
		lblNewLabel.setIcon(img);
		getContentPane().add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 38, 409, 116);
		getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblCantidadDePuntos = new JLabel("CANTIDAD DE PUNTOS:");
		lblCantidadDePuntos.setForeground(Color.BLUE);
		lblCantidadDePuntos.setBounds(10, 11, 162, 26);
		panel.add(lblCantidadDePuntos);
		
	
		
		JLabel lblEquivalenciaEnSoles = new JLabel("EQUIVALENCIA EN SOLES:");
		lblEquivalenciaEnSoles.setForeground(Color.BLUE);
		lblEquivalenciaEnSoles.setBounds(10, 48, 177, 26);
		panel.add(lblEquivalenciaEnSoles);
	
		
		JLabel lblEquivalenciaEnDolares = new JLabel("EQUIVALENCIA EN DOLARES:");
		lblEquivalenciaEnDolares.setForeground(Color.BLUE);
		lblEquivalenciaEnDolares.setBounds(10, 79, 177, 26);
		panel.add(lblEquivalenciaEnDolares);
		
		txtPuntos = new JTextField();
		txtPuntos.setColumns(10);
		txtPuntos.setBounds(169, 14, 120, 20);
		panel.add(txtPuntos);
		
		txtSoles = new JTextField();
		txtSoles.setColumns(10);
		txtSoles.setBounds(169, 48, 120, 20);
		panel.add(txtSoles);
		
		txtDolares = new JTextField();
		txtDolares.setColumns(10);
		txtDolares.setBounds(179, 85, 120, 20);
		panel.add(txtDolares);
		
		txtCantidad = new JTextField();
		txtCantidad.setColumns(10);
		txtCantidad.setBounds(268, 14, 86, 20);
		contentPane.add(txtCantidad);
		
		
	}
	void TiendaElectronica(){
		this.setVisible(false);
		ProyectoTiendaElectronica PTE= new ProyectoTiendaElectronica();
		PTE.setVisible(true);
	}
	
	int cantidad,cantP;
	double sol,dolar;
	
	void leeDatos(){
		
		cantidad=Integer.parseInt(txtCantidad.getText());
		
		
	}
	
	void Equivalencia_Puntos(){
		
		cantP=cantidad*50;
		sol=cantP*0.1;
		dolar=sol*0.28;
	}
	void Imprimir(){
		txtPuntos.setText(""+ cantP);
		txtSoles.setText(""+ sol);
		txtDolares.setText((String.format("%.2f", dolar)));
	}
	
	
	
	void Procesar(){
		
		leeDatos();
		Equivalencia_Puntos();
		Imprimir();
		
	}
	void limpiar(){
		txtCantidad.setText(null);
		txtPuntos.setText(null);
		txtSoles.setText(null);
		txtDolares.setText(null);
		txtCantidad.requestFocus();
	}
	}

package swing;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import java.awt.Color;
import javax.swing.JTextPane;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;

public class InformacionEmpresarial extends JDialog {

	private final JPanel contentPanel = new JPanel();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			InformacionEmpresarial dialog = new InformacionEmpresarial();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public InformacionEmpresarial() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(InformacionEmpresarial.class.getResource("/iconos32/signo-de-exclamacion.png")));
		setTitle("Informacion de la empresa");
		setBounds(100, 100, 400, 278);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		setLocationRelativeTo(null);
		
		JLabel lblVentaDeElectrodomesticos = new JLabel("VENTA DE ELECTRODOMESTICOS");
		lblVentaDeElectrodomesticos.setFont(new Font("Verdana", Font.BOLD, 12));
		lblVentaDeElectrodomesticos.setBounds(21, 58, 240, 28);
		contentPanel.add(lblVentaDeElectrodomesticos);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setBounds(0, -4, 384, 51);
			contentPanel.add(buttonPane);
			buttonPane.setLayout(null);
			
			JLabel lblElectroshopping = new JLabel("ELECTROSHOPPING");
			lblElectroshopping.setBounds(100, 11, 202, 32);
			buttonPane.add(lblElectroshopping);
			lblElectroshopping.setFont(new Font("Verdana", Font.BOLD, 15));
			lblElectroshopping.setIcon(new ImageIcon(InformacionEmpresarial.class.getResource("/iconos32/carrito-de-compras.png")));
			lblElectroshopping.setForeground(Color.BLACK);
		}
		{
			JButton cancelButton = new JButton("Cerrar");
			cancelButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					dispose();
				}
			});
			cancelButton.setBounds(10, 180, 122, 41);
			contentPanel.add(cancelButton);
			cancelButton.setIcon(new ImageIcon(InformacionEmpresarial.class.getResource("/iconos32/flecha-hacia-atras.png")));
			cancelButton.setActionCommand("Cancel");
		}
		
		JLabel lblNewLabel = new JLabel("INTEGRANTES:");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel.setBounds(21, 82, 88, 14);
		contentPanel.add(lblNewLabel);
		
		JLabel lblAlexanderVaquezAlcantara = new JLabel("Alexander Josue Vaquez Alcantara");
		lblAlexanderVaquezAlcantara.setBounds(21, 133, 202, 14);
		contentPanel.add(lblAlexanderVaquezAlcantara);
		
		JLabel label = new JLabel("");
		
		label.setBounds(252, 69, 122, 152);
		ImageIcon ico=new ImageIcon(getClass().getResource("customLogo.jpg"));
		ImageIcon img=new ImageIcon(ico.getImage().getScaledInstance(label.getWidth(), label.getHeight(),Image.SCALE_SMOOTH));
		label.setIcon(img);
		contentPanel.add(label);
	}
	
}

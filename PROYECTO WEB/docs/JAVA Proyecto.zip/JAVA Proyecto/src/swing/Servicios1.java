package swing;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;

public class Servicios1 extends JFrame {

	private JPanel contentPane;
	private JTextField txtTiempo;
	private JTextField txtPuntos;
	private JTextField txtCostoS;
	private JTextField txtDpuntos;
	private JTextField txtcosT;
	private JComboBox cboProductos;
	private JComboBox cboDistrito;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Servicios1 frame = new Servicios1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Servicios1() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(Servicios1.class.getResource("/iconos32/innovacion.png")));
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setTitle("Servicios Tecnicos");
		setBounds(100, 100, 445, 410);
		getContentPane().setLayout(null);
		contentPane.setLayout(null);
		setLocationRelativeTo(null);
		
		JLabel label = new JLabel("PRODUCTOS");
		label.setForeground(Color.BLUE);
		label.setBounds(10, 11, 89, 26);
		getContentPane().add(label);
		
		JLabel lblDistrito = new JLabel("DISTRITO");
		lblDistrito.setForeground(Color.BLUE);
		lblDistrito.setBounds(10, 76, 89, 20);
		getContentPane().add(lblDistrito);
		
		cboProductos = new JComboBox();
		cboProductos.setModel(new DefaultComboBoxModel(new String[] {"Tostadoras", "Planchas", "Lavadoras", "Licuadoras", "Microondas", "Refrigeradoras", "Cocinas", "Ollas "}));
		cboProductos.setBounds(10, 39, 89, 37);
		getContentPane().add(cboProductos);
		
		cboDistrito = new JComboBox();
		cboDistrito.setModel(new DefaultComboBoxModel(new String[] {"Trujillo", "La Esperanza", "Florencia de Mora", "El Porvenir", "Huanchaco"}));
		cboDistrito.setBounds(10, 107, 89, 37);
		getContentPane().add(cboDistrito);
		
		JLabel lblNewLabel = new JLabel("r");
		
		lblNewLabel.setBounds(226, 11, 193, 294);
		ImageIcon ico=new ImageIcon(getClass().getResource("servicio tecnico.jpg"));
		ImageIcon img=new ImageIcon(ico.getImage().getScaledInstance(lblNewLabel.getWidth(), lblNewLabel.getHeight(),Image.SCALE_SMOOTH));
		lblNewLabel.setIcon(img);
		getContentPane().add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 149, 206, 156);
		getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblCostoDelServicio = new JLabel("Costo del servicio");
		lblCostoDelServicio.setForeground(Color.BLUE);
		lblCostoDelServicio.setBounds(10, 11, 127, 20);
		panel.add(lblCostoDelServicio);
		
	
		
		JLabel lblDescuentoPorPuntos = new JLabel("Descuento por puntos");
		lblDescuentoPorPuntos.setForeground(Color.BLUE);
		lblDescuentoPorPuntos.setBounds(10, 63, 151, 20);
		panel.add(lblDescuentoPorPuntos);
		
	
		
		JLabel lblCostoTotal = new JLabel("Costo total");
		lblCostoTotal.setForeground(Color.BLUE);
		lblCostoTotal.setBounds(10, 104, 127, 20);
		panel.add(lblCostoTotal);
		
		txtCostoS = new JTextField();
		txtCostoS.setColumns(10);
		txtCostoS.setBounds(8, 32, 86, 20);
		panel.add(txtCostoS);
		
		txtDpuntos = new JTextField();
		txtDpuntos.setColumns(10);
		txtDpuntos.setBounds(10, 83, 86, 20);
		panel.add(txtDpuntos);
		
		txtcosT = new JTextField();
		txtcosT.setColumns(10);
		txtcosT.setBounds(10, 125, 86, 20);
		panel.add(txtcosT);
		
	
		
		JButton button = new JButton("REGRESAR");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TiendaElectronica();
			}
		});
		button.setIcon(new ImageIcon(Servicios1.class.getResource("/iconos32/carpeta.png")));
		button.setBounds(10, 316, 147, 41);
		getContentPane().add(button);
		
		JButton button_1 = new JButton("");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Limpiar();
			}
		});
		button_1.setIcon(new ImageIcon(Servicios1.class.getResource("/iconos32/add-file.png")));
		button_1.setBounds(364, 316, 55, 41);
		getContentPane().add(button_1);
		
		JButton button_2 = new JButton("");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Procesar();
			}
		});
		button_2.setIcon(new ImageIcon(Servicios1.class.getResource("/iconos32/proceso-automatizado.png")));
		button_2.setBounds(299, 316, 55, 41);
		getContentPane().add(button_2);
		
		JLabel lblTiempo = new JLabel("TIEMPO/A\u00D1OS");
		lblTiempo.setForeground(Color.BLUE);
		lblTiempo.setBounds(109, 11, 99, 26);
		getContentPane().add(lblTiempo);
		
		
		
		JLabel lblPuntos = new JLabel("PUNTOS");
		lblPuntos.setForeground(Color.BLUE);
		lblPuntos.setBounds(119, 73, 71, 26);
		getContentPane().add(lblPuntos);
		
		txtTiempo = new JTextField();
		txtTiempo.setColumns(10);
		txtTiempo.setBounds(109, 39, 99, 37);
		contentPane.add(txtTiempo);
		
		txtPuntos = new JTextField();
		txtPuntos.setColumns(10);
		txtPuntos.setBounds(109, 101, 99, 37);
		contentPane.add(txtPuntos);
		
		

	}
	void TiendaElectronica(){
		this.setVisible(false);
		ProyectoTiendaElectronica PTE= new ProyectoTiendaElectronica();
		PTE.setVisible(true);
	}
	

	int Gproduc,distrito,a�os,puntos,produc,Tgarantia;
	double cosT,Dpuntos,cosS;
	
	
	int[]Garantia_Productos;
	int[]Arreglo_Productos;
	
	void leeDatos(){
		produc=cboProductos.getSelectedIndex();
		distrito=cboDistrito.getSelectedIndex();
		a�os=Integer.parseInt(txtTiempo.getText());
		puntos=Integer.parseInt(txtPuntos.getText());
		
		//Garantias
		 Garantia_Productos=new int [8];
		 Garantia_Productos[0]=2;
		 Garantia_Productos[1]=1;
		 Garantia_Productos[2]=2;
		 Garantia_Productos[3]=1;
		 Garantia_Productos[4]=2;
		 Garantia_Productos[5]=3;
		 Garantia_Productos[6]=1;
		 Garantia_Productos[7]=1;
		 
		 
		 
		 
	
	 
	 //Arreglos
		 Arreglo_Productos=new int[8];
		 Arreglo_Productos[0]=80;
		 Arreglo_Productos[1]=70;
		 Arreglo_Productos[2]=150;
		 Arreglo_Productos[3]=80;
		 Arreglo_Productos[4]=85;
		 Arreglo_Productos[5]=150;
		 Arreglo_Productos[6]=160;
		 Arreglo_Productos[7]=20;
		 	
	}
	
	 void Invocar(){
		 switch(produc){
		 case 0:
			 Tgarantia=Garantia_Productos[0];
			 Gproduc=Arreglo_Productos[0];
			 
			 break;
		 case 1:
			 Tgarantia=Garantia_Productos[1];
			 Gproduc=Arreglo_Productos[1];
			 
			 break;
		 case 2:
			 Tgarantia=Garantia_Productos[2];
			 Gproduc=Arreglo_Productos[2];
			 
			 break;
		 case 3:
			 Tgarantia=Garantia_Productos[3];
			 Gproduc=Arreglo_Productos[3];
			 
			 break;
		 case 4:
			 Tgarantia=Garantia_Productos[4];
			 Gproduc=Arreglo_Productos[4];
			 
			 break;
		 case 5:
			 Tgarantia=Garantia_Productos[5];
			 Gproduc=Arreglo_Productos[5];
			 
			 break;
		 case 6:
			 Tgarantia=Garantia_Productos[6];
			 Gproduc=Arreglo_Productos[6];
			 
			 break;
		 case 7:
			 Tgarantia=Garantia_Productos[7];
			 Gproduc=Arreglo_Productos[7];
			 
			 break;
			 
	 }
		 Distrito();
	 }
	 void Distrito(){
		 switch(distrito){		 
		 case 0:
			
			 distrito=10;
			 break;
		 case 1:
			 
			 distrito=12;
			 break;
		 case 2:
			
			 distrito=12;
			 break;
		 case 3:
			 
			 distrito=12;
			 break;
		 case 4:
			 
			 distrito=15;
			 break;
		
		
			 
			
			 
		 }
	 }	

	
	 void Calculo(){
	if(Integer.parseInt(txtTiempo.getText())>=Tgarantia){
		 cosS=Gproduc+distrito;
		 Dpuntos=puntos*0.1;
		 cosT=cosS-Dpuntos;
	 }
	else{Dpuntos=cosS=cosT=0;}
	
	}
	 
	 
	 void imprimir(){
		 txtCostoS.setText(""+ cosS);
		 txtDpuntos.setText(""+Dpuntos);
		 txtcosT.setText(""+cosT);
	 }
	 
	 void Procesar(){
		leeDatos();
		Invocar();
		Calculo();
		imprimir();
	}
    void Limpiar(){
    	cboProductos.setSelectedIndex(-1);
    	cboDistrito.setSelectedIndex(-1);
    	txtTiempo.setText(null);
    	txtPuntos.setText(null);
    	txtCostoS.setText(null);
    	txtDpuntos.setText(null);
    	txtcosT.setText(null);
    	cboProductos.requestFocus();
    }
	
}

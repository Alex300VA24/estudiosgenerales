package swing;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Frame;
import java.awt.Image;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.JScrollPane;
import java.awt.Toolkit;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ProyectoTiendaElectronica extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ProyectoTiendaElectronica frame = new ProyectoTiendaElectronica();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ProyectoTiendaElectronica() {
		setResizable(false);
		
		
		setIconImage(Toolkit.getDefaultToolkit().getImage(ProyectoTiendaElectronica.class.getResource("/iconos32/innovacion.png")));
		setTitle("Gestor Principal");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 445, 410);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		setLocationRelativeTo(null);
		
		
		JLabel lblNewLabel = new JLabel("");
		
		lblNewLabel.setBounds(10, 11, 250, 264);
		ImageIcon ico=new ImageIcon(getClass().getResource("dt.common.streams.StreamServer.jpg"));
		ImageIcon img=new ImageIcon(ico.getImage().getScaledInstance(lblNewLabel.getWidth(), lblNewLabel.getHeight(),Image.SCALE_SMOOTH));
		lblNewLabel.setIcon(img);
		contentPane.add(lblNewLabel);
		
		JButton btnProductos = new JButton("Productos");
		btnProductos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				ProcesarProduc();
				
				
				
				
				
			}

			private void setVisible(boolean b) {
				// TODO Auto-generated method stub
				
			}

		    
		});
		btnProductos.setIcon(new ImageIcon(ProyectoTiendaElectronica.class.getResource("/iconos32/carrito-de-compras.png")));
		btnProductos.setBounds(270, 11, 149, 44);
		contentPane.add(btnProductos);
		
		JButton btnComprobantes = new JButton("Comprobantes");
		btnComprobantes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ProcesarCompro();
			}
		});
		btnComprobantes.setIcon(new ImageIcon(ProyectoTiendaElectronica.class.getResource("/iconos32/bolsa-de-dinero.png")));
		btnComprobantes.setBounds(270, 66, 149, 44);
		contentPane.add(btnComprobantes);
		
		JButton btnServicios = new JButton("Servicios");
		btnServicios.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ProcesarServi();
			}
		});
		btnServicios.setIcon(new ImageIcon(ProyectoTiendaElectronica.class.getResource("/iconos32/conversacion.png")));
		btnServicios.setBounds(270, 121, 149, 44);
		contentPane.add(btnServicios);
		
		JButton btnClientes = new JButton("Clientes");
		btnClientes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ProcesarClien();
			}
		});
		btnClientes.setIcon(new ImageIcon(ProyectoTiendaElectronica.class.getResource("/iconos32/grupo.png")));
		btnClientes.setBounds(270, 176, 149, 44);
		contentPane.add(btnClientes);
		
		JButton btnEmpleados = new JButton("Empleados");
		btnEmpleados.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ProcesarEmple();
			}
		});
		btnEmpleados.setIcon(new ImageIcon(ProyectoTiendaElectronica.class.getResource("/iconos32/empleado.png")));
		btnEmpleados.setBounds(270, 231, 149, 44);
		contentPane.add(btnEmpleados);
		
		JButton btnProveedores = new JButton("Proveedores");
		btnProveedores.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ProcesarProver();
			}
		});
		btnProveedores.setIcon(new ImageIcon(ProyectoTiendaElectronica.class.getResource("/iconos32/acuerdo.png")));
		btnProveedores.setBounds(270, 286, 149, 44);
		contentPane.add(btnProveedores);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.GRAY);
		panel.setBounds(10, 285, 250, 66);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JButton btnSalir = new JButton("Salir");
		btnSalir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				Login PTE= new Login();
				PTE.setVisible(true);
			}
		});
		btnSalir.setIcon(new ImageIcon(ProyectoTiendaElectronica.class.getResource("/iconos32/flecha.png")));
		btnSalir.setBounds(64, 11, 124, 44);
		panel.add(btnSalir);
		
		JButton btnInfo = new JButton("info");
		btnInfo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				ProcesarInfo();
				
			}
		});
		btnInfo.setIcon(new ImageIcon(ProyectoTiendaElectronica.class.getResource("/iconos32/signo-de-exclamacion.png")));
		btnInfo.setBounds(340, 338, 79, 23);
		contentPane.add(btnInfo);
	}
	
	void Productos(){
		this.setVisible(false);
		Productos1 produc= new Productos1();
		produc.setVisible(true);
		
	}
	void Clientes(){
		this.setVisible(false);
		Clientes1 clien= new Clientes1();
		clien.setVisible(true);
	}
	void Servicios(){
		this.setVisible(false);
		Servicios1 servi= new Servicios1();
		servi.setVisible(true);
	}
	void Comprobantes(){
		this.setVisible(false);
		Comprobantes1 compro= new Comprobantes1();
		compro.setVisible(true);
	}
	void Proveedores(){
		this.setVisible(false);
		Proveedores1 prover= new Proveedores1();
		prover.setVisible(true);
	}
	void Empleados(){
			this.setVisible(false);
			Empleados1 emple= new Empleados1();
			emple.setVisible(true);
		
	}
	void Informacion(){
		InformacionEmpresarial info= new InformacionEmpresarial();
		info.setVisible(true);

	}
	void ProcesarInfo(){
		Informacion();
	}
	void ProcesarEmple(){
		Empleados();
	}
	void ProcesarProver(){
		Proveedores();
	}
	
	void ProcesarCompro(){
		Comprobantes();
	}
	
	
	void ProcesarServi(){
		Servicios();
	}
	
	void ProcesarProduc(){
		Productos();
		
			
	}
	void ProcesarClien(){
		Clientes();
	}

}

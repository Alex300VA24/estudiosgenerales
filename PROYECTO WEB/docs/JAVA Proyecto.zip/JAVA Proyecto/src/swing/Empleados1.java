package swing;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Toolkit;

public class Empleados1 extends JFrame {

	private JPanel contentPane;
	private JTextField txtVentas;
	private JTextField txtImSueldo;
	private JTextField txtImTotal;
	private JTextField txtBono;
	private JTextField txtBventas;
	private JComboBox cboEmpleados;
	private JComboBox cboMes;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Empleados1 frame = new Empleados1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Empleados1() {
		setResizable(false);
		setIconImage(Toolkit.getDefaultToolkit().getImage(Empleados1.class.getResource("/iconos32/innovacion.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 445, 443);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setIcon(true);
		setTitle("Empleados");
		setBounds(100, 100, 445, 410);
		getContentPane().setLayout(null);
		contentPane.setLayout(null);
		setLocationRelativeTo(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 11, 409, 123);
		getContentPane().add(panel);
		panel.setLayout(null);
		
		cboEmpleados = new JComboBox();
		cboEmpleados.setModel(new DefaultComboBoxModel(new String[] {"Vendedores", "Cajeros", "Supervisor"}));
		cboEmpleados.setBounds(10, 52, 98, 44);
		cboEmpleados.addActionListener (new ActionListener () {
		    public void actionPerformed(ActionEvent e) {
		     
		       switch(cboEmpleados.getSelectedIndex()){
		       case 0:
		    	   txtVentas.setEnabled(true); 
		    	   txtBventas.setEnabled(true);
		    	   break;
		       case 1: 
		       case 2:
		    	   txtVentas.setText("");
		    	   txtVentas.setEnabled(false);
		    	   txtBventas.setText("");
		    	   txtBventas.setEnabled(false);
		    	   
		    	   break;
		       }
		    }
		});
		panel.add(cboEmpleados);
		
		JLabel lblNewLabel = new JLabel("EMPLEADOS");
		lblNewLabel.setIcon(new ImageIcon(Empleados1.class.getResource("/iconos32/redes.png")));
		lblNewLabel.setForeground(Color.BLUE);
		lblNewLabel.setBounds(10, 8, 108, 33);
		panel.add(lblNewLabel);
		
		JLabel lblMes = new JLabel("  MES");
		lblMes.setIcon(new ImageIcon(Empleados1.class.getResource("/iconos32/pequena-pagina-del-calendario.png")));
		lblMes.setForeground(Color.BLUE);
		lblMes.setBounds(174, 11, 86, 33);
		panel.add(lblMes);
		
		cboMes = new JComboBox();
		cboMes.setModel(new DefaultComboBoxModel(new String[] {"Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"}));
		cboMes.setBounds(174, 52, 86, 44);
		panel.add(cboMes);
		
		JLabel lblVentas = new JLabel("VENTAS");
		lblVentas.setIcon(new ImageIcon(Empleados1.class.getResource("/iconos32/mejor-precio.png")));
		lblVentas.setForeground(Color.BLUE);
		lblVentas.setBounds(299, 11, 85, 33);
		panel.add(lblVentas);
		
		txtVentas = new JTextField();
		txtVentas.setColumns(10);
		txtVentas.setBounds(299, 52, 86, 44);
		
		panel.add(txtVentas);
		
		
		
		JButton btnRegresar = new JButton("REGRESAR");
		btnRegresar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TiendaElectronica();
			}
		});
		btnRegresar.setIcon(new ImageIcon(Empleados1.class.getResource("/iconos32/carpeta.png")));
		btnRegresar.setBounds(23, 319, 144, 41);
		getContentPane().add(btnRegresar);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(10, 145, 409, 160);
		getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblImporteDeSueldo = new JLabel("Importe de sueldo");
		lblImporteDeSueldo.setForeground(Color.BLUE);
		lblImporteDeSueldo.setBounds(10, 0, 103, 33);
		panel_1.add(lblImporteDeSueldo);
		
		
		
		JLabel lblBonoDeMes = new JLabel("Bono de mes");
		lblBonoDeMes.setForeground(Color.BLUE);
		lblBonoDeMes.setBounds(305, 0, 104, 33);
		panel_1.add(lblBonoDeMes);
		
		
		
		JLabel lblBonoDeVentas = new JLabel("Bono de ventas");
		lblBonoDeVentas.setForeground(Color.BLUE);
		lblBonoDeVentas.setBounds(305, 76, 104, 33);
		panel_1.add(lblBonoDeVentas);
		
		
		
		JLabel lblImporteTotal = new JLabel("Importe total");
		lblImporteTotal.setForeground(Color.BLUE);
		lblImporteTotal.setBounds(10, 79, 103, 33);
		panel_1.add(lblImporteTotal);
		
		
		
		JLabel lblNewLabel_1 = new JLabel("");
		
		lblNewLabel_1.setBounds(114, 0, 181, 160);
		ImageIcon ico=new ImageIcon(getClass().getResource("empleados.jpg"));
		ImageIcon img=new ImageIcon(ico.getImage().getScaledInstance(lblNewLabel_1.getWidth(), lblNewLabel_1.getHeight(),Image.SCALE_SMOOTH));
		lblNewLabel_1.setIcon(img);
		panel_1.add(lblNewLabel_1);
		
		txtImSueldo = new JTextField();
		txtImSueldo.setColumns(10);
		txtImSueldo.setBounds(10, 35, 94, 33);
		panel_1.add(txtImSueldo);
		
		txtImTotal = new JTextField();
		txtImTotal.setColumns(10);
		txtImTotal.setBounds(10, 116, 94, 33);
		panel_1.add(txtImTotal);
		
		txtBono = new JTextField();
		txtBono.setColumns(10);
		txtBono.setBounds(305, 32, 94, 33);
		panel_1.add(txtBono);
		
		txtBventas = new JTextField();
		txtBventas.setColumns(10);
		txtBventas.setBounds(305, 116, 94, 33);
		panel_1.add(txtBventas);
		
		JButton button = new JButton("");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Limpiar();
			}
		});
		button.setIcon(new ImageIcon(Empleados1.class.getResource("/iconos32/add-file.png")));
		button.setBounds(364, 319, 55, 41);
		getContentPane().add(button);
		
		JButton button_1 = new JButton("");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Procesar();
			}
		});
		button_1.setIcon(new ImageIcon(Empleados1.class.getResource("/iconos32/proceso-automatizado.png")));
		button_1.setBounds(299, 319, 55, 41);
		getContentPane().add(button_1);
	}

	private void setIcon(boolean b) {
		// TODO Auto-generated method stub
		
	}
	void TiendaElectronica(){
		this.setVisible(false);
		ProyectoTiendaElectronica PTE= new ProyectoTiendaElectronica();
		PTE.setVisible(true);
	}
	int empleados,mes,ventas;
	double imSuel,imTotal,Bmes,Bventas;
	
	void leeDatos(){
		empleados=cboEmpleados.getSelectedIndex();
		mes=cboMes.getSelectedIndex();
		if(!txtVentas.getText().isEmpty())
		ventas=Integer.parseInt(txtVentas.getText());
	}
	void ImporteSueldo(){
		switch(empleados){
		case 0: 
			
			Empleados();

		;break;
		case 1: 
			
			Cajeros();
			break;
		case 2: 
			
			Administradores();
			break;
		}
		
		
	}
		void Empleados(){
			switch(mes){
			case 0:
				imSuel=950;
				Bmes=imSuel*0.1;
						break;
			case 1:
				imSuel=950;
				Bmes=imSuel*0.15;
				 break;
			case 2: 
				imSuel=950;
				Bmes=imSuel*0.20;
				break;
			case 3:
				imSuel=950;
				Bmes=imSuel*0.25;
				break;
			case 4:
				imSuel=950;
				Bmes=imSuel*0.30;
				break;
			case 5: 
				imSuel=950;
				Bmes=imSuel*0.35;
				break;
			case 6:
				imSuel=950;
				Bmes=imSuel*0.40;
				break;
			case 7:
				imSuel=950;
				Bmes=imSuel*0.45;
				break;
			case 8:
				imSuel=950;
				Bmes=imSuel*0.50;
				break;
			case 9:
				imSuel=950;
				Bmes=imSuel*0.55;
				break;
			case 10:
				imSuel=950;
				Bmes=imSuel*0.60;
				break;
			case 11:
				imSuel=950;
				Bmes=imSuel*0.65;
				break;
			
			}
		}
		void Cajeros(){
			switch(mes){
			case 0:
				imSuel=1500;
				Bmes=imSuel*0.1;
						break;
			case 1:
				imSuel=1500;
				Bmes=imSuel*0.15;
				 break;
			case 2: 
				imSuel=1500;
				Bmes=imSuel*0.20;
				break;
			case 3:
				imSuel=1500;
				Bmes=imSuel*0.25;
				break;
			case 4:
				imSuel=1500;
				Bmes=imSuel*0.30;
				break;
			case 5: 
				imSuel=1500;
				Bmes=imSuel*0.35;
				break;
			case 6:
				imSuel=1500;
				Bmes=imSuel*0.40;
				break;
			case 7:
				imSuel=1500;
				Bmes=imSuel*0.45;
				break;
			case 8:
				imSuel=1500;
				Bmes=imSuel*0.50;
				break;
			case 9:
				imSuel=1500;
				Bmes=imSuel*0.55;
				break;
			case 10:
				imSuel=1500;
				Bmes=imSuel*0.60;
				break;
			case 11:
				imSuel=1500;
				Bmes=imSuel*0.65;
				break;
			
			}
		}
		void Administradores(){
			switch(mes){
			case 0:
				imSuel=2500;
				Bmes=imSuel*0.1;
						break;
			case 1:
				imSuel=2500;
				Bmes=imSuel*0.15;
				 break;
			case 2: 
				imSuel=2500;
				Bmes=imSuel*0.20;
				break;
			case 3:
				imSuel=2500;
				Bmes=imSuel*0.25;
				break;
			case 4:
				imSuel=2500;
				Bmes=imSuel*0.30;
				break;
			case 5: 
				imSuel=2500;
				Bmes=imSuel*0.35;
				break;
			case 6:
				imSuel=2500;
				Bmes=imSuel*0.40;
				break;
			case 7:
				imSuel=2500;
				Bmes=imSuel*0.45;
				break;
			case 8:
				imSuel=2500;
				Bmes=imSuel*0.50;
				break;
			case 9:
				imSuel=2500;
				Bmes=imSuel*0.55;
				break;
			case 10:
				imSuel=2500;
				Bmes=imSuel*0.60;
				break;
			case 11:
				imSuel=2500;
				Bmes=imSuel*0.65;
				break;
			
			}
			Bmes=Math.round((Bmes) * 100.0) / 100.0;
		}
	 void BonoVentas(){
		 //System.out.println(cboEmpleados.getSelectedIndex());
		 if(cboEmpleados.getSelectedIndex()==0)
		 Bventas=ventas*20;
		 else Bventas=0;
	 }
	void ImporteTotal(){
		if(imSuel==950)
		  imTotal=imSuel+Bmes+Bventas;
		else if(imSuel==1500 || imSuel==2500)
			imTotal=imSuel+Bmes;
		
	}
	void Imprimir(){
		txtImSueldo.setText(""+imSuel);
		txtBono.setText(""+Bmes);
		txtImTotal.setText(""+imTotal);
		if(Bventas!=0)
		txtBventas.setText(""+Bventas);
	}
	
	void Procesar(){
		
		leeDatos();
		ImporteSueldo();
		BonoVentas();
		ImporteTotal();
		Imprimir();
		
	}
	void Limpiar(){
		cboEmpleados.setSelectedIndex(-1);
		cboMes.setSelectedIndex(-1);
		txtVentas.setText(null);
		txtImSueldo.setText(null);
		txtBono.setText(null);
		txtImTotal.setText(null);
		txtBventas.setText(null);
		txtImSueldo.requestFocus();
		
	}

}
